import request from '@/utils/request';
import { AxiosPromise } from 'axios';

interface materials {
  eqpId: string;
  lotId: string;
  trackStatus?: 0 | 1;
}

type boxComparedTypes = {
  lotId: string;
  eqpId: string;
  barCode: string;
};

export type consumablesComparedTypes = {
  lotId: string;
  eqpId: string;
  consumablesInfocount: Array<{
    innerThread: string;
    bondingHead: string;
    Checked: 0;
    consumablesType: string;
    consumablesBarCode: string;
  }>;
};

export type materialComparedTypes = {
  lotId: string;
  eqpId: string;
  materail: [
    {
      bondingHead: string;
      Checked: 0;
      materialType: string;
      materialBarCode: string;
    },
  ];
};

export interface MaterialCompared {
  eqpId?: string;
  lotId?: string;
  consumablesInfocount?: any;
  barCode?: string;
}

export interface materialComparedCheck {
  consumablesType: string;
  lotId: string;
  eqpId: string;
  consumablesBarCode: string;
  stepId: string;
  innerThread: string;
}

export type CheckConsumablesInfo = {
  consumablesNo: string;
  consumablesDesc: string;
  lifeTimes: string;
  limitTimes: string;
  stageTimes: string;
};

// 初始化
export function getMaterials(params: materials) {
  return request('/tms/Materials/GetMaterial', {
    method: 'get',
    params: params,
  });
}

// 确认新增
export function doUpdate(params: MaterialCompared) {
  return request('/tms/Materials/MaterialCompared', {
    method: 'POST',
    data: params,
  });
}

export function getMaterialHistory(params: materials) {
  return request('/tms/Materials/GetMaterialHistory', {
    method: 'get',
    params: params,
  });
}

//料盒对比
export function boxCompared(params: boxComparedTypes) {
  return request('/tms/Materials/BoxCompared', {
    method: 'POST',
    data: params,
  });
}

//耗材对比
export function consumablesCompared(params: consumablesComparedTypes) {
  return request('/tms/Materials/ConsumablesCompared', {
    method: 'POST',
    data: params,
  });
}

//材料对比
export function materialCompared(params: materialComparedTypes) {
  return request('/tms/Materials/MaterialCompared', {
    method: 'POST',
    data: params,
  });
}

//显示剩余寿命
export function checkAndGetConsumablesInfo(
  params: materialComparedCheck,
): AxiosPromise<CheckConsumablesInfo> {
  return request('/tms/Materials/CheckAndGetConsumablesInfo', {
    method: 'POST',
    data: params,
  });
}

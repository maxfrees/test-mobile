import { UploadRecipeProps } from '@/screens/UploadRecipe/UploadRecipe';
import request from '@/utils/request';

export function getRecipes(params: { eqpId: string }) {
  return request('/tms/recipe/GetRecipes', {
    method: 'get',
    params: params,
  });
}

export function uploadRecipes(params: UploadRecipeProps) {
  return request('/tms/recipe/Upload', {
    method: 'POST',
    data: params,
  });
}

export function authenticateUser(params: { userID: string; password: string }) {
  return request('/tms/recipe/AuthenticateUser', {
    method: 'get',
    params: params,
  });
}

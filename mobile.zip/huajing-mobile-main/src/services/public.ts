import { AxiosPromise } from 'axios';
import { LotInfoType } from '@/types/lotinfo';
import request from '@/utils/request';

interface LotInfoParams {
  eqpId: string;
  lotId?: string;
  trackInPage?: number;
}

interface CheckUpdateParams {
  isUpdate: 0 | 1;
  versionCode: string;
  versionName: string;
  apkUrl: string;
  updateLog: string;
  apkSize: string;
}

// 工单信息
export function getLotInfo(params: LotInfoParams): AxiosPromise<LotInfoType> {
  return request('/tms/MainPage/GetLotInfo', {
    method: 'get',
    params: params,
  });
}

// 材料信息
export function getAllMaterial(params: LotInfoParams) {
  return request('/tms/MainPage/GetAllMaterial', {
    method: 'get',
    params: params,
  });
}

// 材料信息
export function handleCheckUpdate(params: {
  version: string;
}): AxiosPromise<CheckUpdateParams> {
  return request('/config/Upgrade/Check', {
    method: 'get',
    params: params,
  });
}

export function closeWSConnection(params: {
  eqpId: string;
}): AxiosPromise<CheckUpdateParams> {
  return request('/ws/WebSocket/DisConnection', {
    method: 'get',
    params: params,
  });
}

export function checkAuthority(params: {
  userName: string;
  roleName: string;
}): AxiosPromise<boolean> {
  return request('/config/Role/CheckAuthority', {
    method: 'get',
    params: params,
  });
}

export function clearEAPLotInfo(data: {
  eqpId: string;
  testerId: string;
  lotId: string;
}): AxiosPromise<any> {
  return request('/tms/HJTrakIn/ClearEAPLotInfo', {
    method: 'post',
    data: data,
  });
}

import request from '@/utils/request';

export function getCardPath(params: { processCard: string }) {
  return request('/tms/MainPage/GetProcessCardPath', {
    method: 'get',
    params: params,
  });
}

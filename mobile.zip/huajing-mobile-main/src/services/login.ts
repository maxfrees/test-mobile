import { AxiosPromise } from 'axios';
import { getToken } from '@/utils/auth';
import request from '@/utils/request';

type UserLoginParams = {
  username: string;
  password: string;
  ipaddress: string;
  loginType: number;
};

type updateOperIdParams = {
  eqpId: string;
  operId: string;
};

export type updatePwdType = {
  id: string;
  oldpassword: string;
  newpassword: string;
};

export function accountLogin(
  params: UserLoginParams,
): AxiosPromise<{ token: string; eqpid: string; user: any }> {
  return request('/config/Login/Login', {
    method: 'POST',
    data: params,
  });
}

export function updatePasswordByUserId(params: updatePwdType) {
  return request('/config/user/UpdatePasswordByUserId', {
    method: 'POST',
    data: params,
  });
}

export async function updateOperId(params: updateOperIdParams) {
  const authToken = await getToken();
  return request('/tms/MainPage/UpdateOperId', {
    method: 'POST',
    data: params,
    headers: {
      Token: authToken || '',
    },
  });
}

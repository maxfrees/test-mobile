import { scrapProps } from '@/screens/TrackOut/components/Scrap';
import request from '@/utils/request';

interface TrackOutParams {
  lotHistoryId?: string;
  eqpId?: string;
  lotId?: string;
  remainingQty?: string;
  jobNum?: string;
  boxs?: string;
  scrapList?: scrapProps[];
  defectiveList?: scrapProps[];
  headList?: String[];
}

interface YieldInfoParams {
  eqpId: string;
  lotId: string;
  stepID: string;
}

export function doTrackOut(params: TrackOutParams) {
  return request('/tms/HJTrackOut/TrackOut', {
    method: 'POST',
    data: params,
  });
}

// 获取产量信息
export function getYieldInfo(params: YieldInfoParams) {
  return request('/tms/HandOver/GetYieldInfo', {
    method: 'get',
    params: params,
  });
}

// 原因代码
export function getReason(params: { statusCode: string; type: number }) {
  return request('/tms/MainPage/GetReason', {
    method: 'get',
    params: params,
  });
}

// 校验弹出数量差异提示
export function checkIsQtyDiff(params: { eqpId: string; lotId?: string }) {
  return request('/tms/HJTrackOut/CheckIsQtyDiff', {
    method: 'post',
    data: params,
  });
}

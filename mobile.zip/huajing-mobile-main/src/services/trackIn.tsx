import useRequest from '@/hooks/useRequest';
import request from '@/utils/request';

interface TrackInParams {
  eqpId: string;
  lotId: string;
}

interface MESEqpStatusModel {
  eqpId: string;
  eqpStatus: string;
}

const MESEqpStatusUrl =
  '/tms/EquipmentRealtimeMonitor/GetHJMESEqpStatusByEQPName';

export function doTrackIn(params: TrackInParams) {
  return request('/tms/HJTrakIn/TrackIn', {
    method: 'POST',
    data: params,
  });
}

export function getMESEqpStatusByEQPName(
  params: Pick<MESEqpStatusModel, 'eqpId'>,
) {
  return request(MESEqpStatusUrl, {
    method: 'GET',
    params: params,
  });
}

export function useMESEqpStatus(eqpId: string) {
  const { data } = useRequest<MESEqpStatusModel>({
    url: MESEqpStatusUrl,
    method: 'GET',
    params: { eqpId: eqpId },
  });
  return {
    data,
  };
}

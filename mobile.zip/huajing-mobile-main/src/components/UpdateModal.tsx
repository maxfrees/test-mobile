import React, { useState, useEffect } from 'react';
import { Modal, Heading, Link } from 'native-base';
import { handleCheckUpdate } from '@/services/public';
import { BASE_API } from '@/utils/request';

type UpdateModalTypes = {
  needOpen?: boolean;
  updateURL?: string;
  closeModal?: (status: boolean) => void;
};

const UpdateModal: React.FC<UpdateModalTypes> = ({
  needOpen = false,
  updateURL = '',
  closeModal = () => {},
}) => {
  const [showModal, setShowModal] = useState<boolean>(needOpen);
  const [updateUrl, setUpdateUrl] = useState<string>(updateURL);

  useEffect(() => {
    const checkVersion = async () => {
      try {
        const fileJSON = require('../../package.json');
        const res = await handleCheckUpdate({ version: fileJSON.version });
        const { isUpdate, apkUrl } = res.data;
        setShowModal(isUpdate ? true : false);
        setUpdateUrl(apkUrl);
      } catch (error) {
        setShowModal(false);
        setUpdateUrl('');
      }
    };
    if (!needOpen) {
      checkVersion();
    }
  }, [needOpen]);

  return (
    <Modal
      isOpen={showModal}
      onClose={() => {
        setShowModal(false);
        closeModal(false);
      }}>
      <Modal.Content maxWidth="400">
        <Modal.CloseButton />
        <Modal.Header>版本更新</Modal.Header>
        <Modal.Body>
          <Heading size="md">
            <Link
              href={BASE_API + '/' + updateUrl}
              isExternal
              _text={{
                color: 'blue.500',
              }}>
              发现新版本, 点击去更新
            </Link>
          </Heading>
        </Modal.Body>
      </Modal.Content>
    </Modal>
  );
};

export default UpdateModal;

import { colorPrimary } from '@/theme/theme';
import React, { useEffect } from 'react';
import { StyleSheet, View, ActivityIndicator, BackHandler } from 'react-native';

const Loading: React.FC = () => {
  return (
    <View
      style={{
        width: '100%',
        height: '100%',
        backgroundColor: 'rgba(0,0,0,0.3)',
        ...StyleSheet.absoluteFillObject,
        zIndex: 1,
        justifyContent: 'center',
      }}>
      <ActivityIndicator size="small" color={colorPrimary} />
    </View>
  );
};

const Spin: React.FC<{ loading: boolean }> = ({ loading }) => {
  useEffect(() => {
    const backHandler = BackHandler.addEventListener(
      'hardwareBackPress',
      function () {
        if (loading) {
          /**
           * 返回true时会阻止事件冒泡传递，因而不会执行默认的后退行为
           */
          return true;
        }
        /**
         * 返回false时会使事件继续传递，触发其他注册的监听函数，或是系统默认的后退行为
         */
        return false;
      },
    );
    return () => backHandler.remove();
  }, [loading]);

  return loading ? <Loading /> : null;
};

export default Spin;

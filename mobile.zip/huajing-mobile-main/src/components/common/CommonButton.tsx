import { isPromise } from '@/utils/is';
import { Button, IButtonProps } from 'native-base';
import React, { useState } from 'react';

interface CommonButtonProps {
  loading?: boolean;
  isDisabled?: boolean;
  onPress?: () => void | Promise<any>;
}

const CommonButton: React.FC<CommonButtonProps & IButtonProps> = ({
  loading = false,
  isDisabled = false,
  onPress,
  children,
  ...props
}) => {
  const [btnLoading, setLoading] = useState<boolean>(loading);

  const handlePress = () => {
    if (onPress) {
      const ret = onPress();

      if (ret && isPromise(ret)) {
        setLoading(true);
        ret.finally(() => {
          setLoading(false);
        });
      }
    }
  };
  return (
    <Button
      {...props}
      isLoading={btnLoading}
      isDisabled={btnLoading || isDisabled}
      onPress={handlePress}>
      {children}
    </Button>
  );
};

export default CommonButton;

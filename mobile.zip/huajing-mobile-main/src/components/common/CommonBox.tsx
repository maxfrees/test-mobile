import { Box, IBoxProps } from 'native-base';
import React from 'react';
import { StyleProp, View, ViewStyle } from 'react-native';

type Props = {
  children?: React.ReactNode;
  style?: StyleProp<ViewStyle>;
  boxProps?: IBoxProps;
};

const CommonBox = ({ children, style, boxProps }: Props) => {
  return (
    <View
      style={[
        {
          padding: 10,
          borderRadius: 10,
        },
        style,
      ]}>
      <Box bg="white" rounded="lg" style={{ padding: 8 }} {...boxProps}>
        {children}
      </Box>
    </View>
  );
};

export default CommonBox;

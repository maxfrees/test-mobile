import React, { useCallback, useState } from 'react';
import {
  LayoutChangeEvent,
  LayoutRectangle,
  StyleProp,
  StyleSheet,
  View,
  ViewStyle,
} from 'react-native';

interface GridViewProps {
  style?: StyleProp<ViewStyle>;
  numOfRow?: number;
  horizontalSpacing?: number;
  verticalSpacing?: number;
}

const CommonGridView: React.FC<GridViewProps> = ({
  style,
  numOfRow = 3,
  horizontalSpacing = 16,
  verticalSpacing = 8,
  children,
}) => {
  const [layout, setLayout] = useState<LayoutRectangle>({
    x: 0,
    y: 0,
    width: 0,
    height: 0,
  });

  const itemWidth =
    (layout.width - (numOfRow - 1) * horizontalSpacing - 0.5) / numOfRow;

  const childCount = React.Children.count(children);

  const onLayout = useCallback((e: LayoutChangeEvent) => {
    setLayout(e.nativeEvent.layout);
  }, []);

  return (
    <View style={[styles.container, style]} onLayout={onLayout}>
      {React.Children.map(children, function (child: any, index) {
        const cStyle = child.props.style;
        return React.cloneElement(child, {
          style: [
            cStyle,
            {
              width: itemWidth,
              marginLeft: index % numOfRow !== 0 ? horizontalSpacing : 0,
              marginBottom:
                Math.floor(index / numOfRow) <
                Math.floor((childCount - 1) / numOfRow)
                  ? verticalSpacing
                  : 0,
            },
          ],
        });
      })}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'flex-start',
  },
});

export default CommonGridView;

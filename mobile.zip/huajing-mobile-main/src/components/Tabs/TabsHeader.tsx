import React from 'react';
import { View } from 'react-native';
import TabsHeaderItem from './TabsHeaderItem';

interface TabsHeaderProps {
  children: any;
  index: number;
  goTo: (index: number) => void;
}

const TabsHeader: React.FC<TabsHeaderProps> = ({ children, goTo, index }) => {
  return (
    <View
      style={{
        flexDirection: 'row',
        borderRadius: 6,
        paddingVertical: 4,
      }}>
      {React.Children.map(children, (tab, tabIndex) => {
        return (
          <TabsHeaderItem
            tab={tab}
            goTo={goTo}
            tabIndex={tabIndex}
            active={tabIndex === index}
          />
        );
      })}
    </View>
  );
};

export default TabsHeader;

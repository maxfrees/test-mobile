import Tabs from './Tab';
import TabScreen from './TabScreen';

export { Tabs, TabScreen };

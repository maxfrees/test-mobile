import React from 'react';
import { useContext } from 'react';

interface TabsContextProps {
  goTo: (index: number) => void;
  index: number;
}

export const TabsContext = React.createContext<TabsContextProps>({
  goTo: () => null,
  index: 0,
});

export function useTabNavigation() {
  return useContext(TabsContext).goTo;
}
export function useTabIndex() {
  return useContext(TabsContext).index;
}

import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ScrollView, useWindowDimensions, View } from 'react-native';
import { TabsContext } from './context';
import TabsHeader from './TabsHeader';

interface TabsProps {
  defaultIndex?: number;
  onChangeIndex?: (index: number) => void;
  children?: React.ReactNode[];
  showType?: 'scroll' | 'flex';
}

const Tabs: React.FC<TabsProps> = ({
  children,
  defaultIndex = 0,
  onChangeIndex,
  showType = 'flex',
}) => {
  const [index, setIndex] = useState<number>(defaultIndex || 0);

  const scrollRef = useRef<ScrollView | null>(null);

  const windowWidth = useWindowDimensions().width;

  const goTo = useCallback(
    (ind: number) => {
      setIndex(ind);
      onChangeIndex?.(ind);
    },
    [onChangeIndex],
  );

  const renderProps = {
    index,
    goTo,
    children,
  };

  useEffect(() => {
    if (scrollRef.current && showType === 'scroll') {
      scrollRef.current.scrollTo({
        x: windowWidth * index,
        animated: true,
      });
    }
  }, [windowWidth, index, showType]);

  useEffect(() => {
    setIndex(defaultIndex);
  }, [defaultIndex]);

  return (
    <View style={{ flex: 1 }}>
      <TabsHeader {...renderProps} />
      <TabsContext.Provider value={{ goTo, index }}>
        {showType === 'scroll' ? (
          <ScrollView
            horizontal
            scrollEnabled={false}
            showsHorizontalScrollIndicator={false}
            snapToAlignment="center"
            ref={e => {
              if (e) {
                scrollRef.current = e;
              }
            }}>
            {children}
          </ScrollView>
        ) : (
          React.Children.map(children, (tab, i) => {
            return (
              <View style={{ display: index === i ? 'flex' : 'none' }}>
                {tab}
              </View>
            );
          })
        )}
      </TabsContext.Provider>
    </View>
  );
};

export default Tabs;

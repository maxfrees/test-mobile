import * as React from 'react';
import type { GestureResponderEvent } from 'react-native';

export interface TabScreenProps {
  label: string;
  children: any;
  onPress?: (event: GestureResponderEvent) => void;
}

export default function TabScreen({ children }: TabScreenProps) {
  return React.Children.only(children);
}

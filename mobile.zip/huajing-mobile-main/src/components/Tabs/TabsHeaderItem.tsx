import React, { ReactElement } from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { TabScreenProps } from './TabScreen';
import { colorPrimary } from '@/theme/theme';

export interface TabsHeaderItemProps {
  tab: ReactElement<TabScreenProps>;
  tabIndex: number;
  goTo: (index: number) => void;
  active: boolean;
}

const TabsHeaderItem: React.FC<TabsHeaderItemProps> = ({
  tab,
  goTo,
  tabIndex,
  active,
}) => {
  return (
    <TouchableOpacity
      key={tab.props.label}
      style={styles.headerItemWrapped}
      onPress={() => {
        goTo(tabIndex);
      }}>
      <Text style={[styles.btnTab, active ? styles.tabActive : null]}>
        {tab.props.label}
      </Text>
      <View style={[styles.indicator, { width: active ? 40 : 0 }]} />
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  headerItemWrapped: {
    flexDirection: 'column',
    alignItems: 'center',
  },
  btnTab: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    textAlign: 'center',
    borderTopRightRadius: 6,
    borderTopLeftRadius: 6,
    color: '#333',
  },
  tabActive: {
    color: colorPrimary,
  },
  indicator: {
    height: 2,
    backgroundColor: colorPrimary,
    borderRadius: 4,
  },
});
export default TabsHeaderItem;

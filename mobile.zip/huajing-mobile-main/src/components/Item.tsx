import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Pressable } from 'native-base';
import {
  IconOutline,
  OutlineGlyphMapType,
} from '@ant-design/icons-react-native';

interface IProps {
  title: string;
  rightDescribe?: string;
  iconName: OutlineGlyphMapType;
  showRightIcon?: boolean;
  onPress?: () => void;
}

export const Item: React.FC<IProps> = ({
  title,
  rightDescribe,
  iconName,
  showRightIcon = true,
  onPress,
}) => {
  return (
    <Pressable style={styles.item} onPress={onPress}>
      <View style={styles.itemLeft}>
        <IconOutline name={iconName} size={20} style={{ paddingRight: 8! }} />
        <Text>{title}</Text>
      </View>
      <View style={styles.itemRight}>
        <Text>{rightDescribe}</Text>
        {!!showRightIcon && (
          <IconOutline name="right" size={20} style={{ paddingLeft: 8! }} />
        )}
      </View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  item: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: 'rgb(221, 221, 221)',
  },
  itemLeft: {
    paddingRight: 10,
    flexDirection: 'row',
  },
  itemRight: {
    flex: 1,
    height: '100%',
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
});

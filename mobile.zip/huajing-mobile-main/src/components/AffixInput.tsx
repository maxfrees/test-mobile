import React, { useEffect, useState } from 'react';
import { IInputProps, Input } from 'native-base';
import { View, TouchableOpacity, StyleSheet } from 'react-native';
import { IconOutline } from '@ant-design/icons-react-native';

interface IProps {
  placeholder?: string;
  onChangeText?: (value: string) => void;
  value?: string;
  inputRef?: any;
}

const AffixInput: React.FC<IProps & IInputProps> = ({
  placeholder = '',
  onChangeText,
  value = '',
  inputRef,
  ...props
}) => {
  const [input, setInput] = useState<string>('');

  const changeText = (text: string) => {
    if (props.isDisabled) {
      return;
    }
    setInput(text);
    onChangeText && onChangeText(text);
  };

  const emptyInput = () => {
    if (props.isDisabled) {
      return;
    }
    setInput('');
    onChangeText && onChangeText('');
  };

  useEffect(() => {
    setInput(value);
  }, [value]);

  return (
    <Input
      InputRightElement={
        <TouchableOpacity style={styles.close} onPress={emptyInput}>
          {input.length && !props.isDisabled ? (
            <View style={styles.closeBorder}>
              <IconOutline name="close" size={10} color="#fff" />
            </View>
          ) : null}
        </TouchableOpacity>
      }
      value={input}
      onChangeText={changeText}
      placeholder={placeholder}
      ref={inputRef}
      {...props}
    />
  );
};

const styles = StyleSheet.create({
  close: {
    height: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 4,
  },
  closeBorder: {
    borderRadius: 50,
    backgroundColor: '#00000040',
    padding: 4,
  },
});

export default AffixInput;

import { MMKV } from 'react-native-mmkv';

export class Storage<T> {
  protected id: string;
  protected store: MMKV;
  constructor({ id }: { id: string }) {
    this.id = id;
    // 方便多个实例
    this.store = new MMKV({ id });
  }

  get(): T | null {
    const value = this.store.getString(this.id);
    return value ? JSON.parse(value) : null;
  }

  set(value: T): void {
    this.store.set(this.id, JSON.stringify(value));
  }

  remove(): void {
    this.store.delete(this.id);
  }

  clearAll(): void {
    this.store.clearAll();
  }
}

import { Storage } from '@/storage';

const TOKEN = '@eqpId' as const;

class EqpIdStorage<T> extends Storage<T> {}

const eqpIdStorage = new EqpIdStorage<string>({ id: TOKEN });

export const getStorageEqpId = () => eqpIdStorage.get();

export const setStorageEqpId = (value: string) => eqpIdStorage.set(value);

export const removeStorageEqpId = () => eqpIdStorage.remove();

import React, { createContext, useState, useCallback } from 'react';
import { removeToken, setToken } from 'src/utils/auth';
import { removeUserInfo, getEqpId } from 'src/utils/user';
import { NativeBaseProvider } from 'native-base';
import { theme } from '@/theme/theme';
import Login from '@/screens/Login';
import UpdateModal from '@/components/UpdateModal';
import { LotInfoType } from '@/types/lotinfo';
import { closeWSConnection } from '@/services/public';

interface ContextProps {
  loginPopup: boolean;
  openLoginPopup: (isOpen: boolean) => void;
  isLogin: boolean;
  isHandOver: boolean;
  changeHandOver: (handover: boolean) => void;
  changeLoginStatus: (login: boolean) => void;
  login: (token: string) => void;
  logout: () => void;
  lotForm: LotInfoType;
  setLotInfo: (info: LotInfoType) => void;
}

export const AuthContext = createContext<ContextProps>({
  loginPopup: false,
  openLoginPopup: () => {},
  isLogin: false,
  isHandOver: false,
  changeHandOver: () => {},
  changeLoginStatus: () => {},
  login: () => {},
  logout: () => {},
  lotForm: {},
  setLotInfo: () => {},
});

export const AuthProvider: React.FC = ({ children }) => {
  const [showloginPopup, setShowloginPopup] = useState<boolean>(false);
  const [isHandOver, setIsHandOver] = useState<boolean>(false);
  const [isLogin, setLoginStatus] = useState(false);
  const [lotForm, setLotForm] = useState<LotInfoType>({});

  const changeLoginStatus = useCallback((isOpen: boolean) => {
    setLoginStatus(isOpen);
  }, []);

  const handleSetLotForm = useCallback((info: LotInfoType) => {
    setLotForm(info);
  }, []);

  return (
    <AuthContext.Provider
      value={{
        loginPopup: showloginPopup,
        openLoginPopup: (isOpen: boolean) => {
          setShowloginPopup(isOpen);
        },
        isLogin,
        changeLoginStatus,
        login: (token: string) => {
          setToken(token);
          setShowloginPopup(false);
          setLoginStatus(true);
          setIsHandOver(false);
        },
        logout: async () => {
          try {
            const eqpId = await getEqpId();
            await removeToken();
            await removeUserInfo();
            await setLoginStatus(false);
            await closeWSConnection({ eqpId });
          } catch (error) {
            // closeWSConnection接口暂时不通
            await removeToken();
            await removeUserInfo();
            await setLoginStatus(false);
          }
        },
        lotForm,
        setLotInfo: handleSetLotForm,
        isHandOver,
        changeHandOver: (handOver: boolean) => {
          setIsHandOver(handOver);
        },
      }}>
      <NativeBaseProvider theme={theme}>
        {children}
        <Login
          isShow={showloginPopup}
          needLogin={(show: boolean) => setShowloginPopup(show)}
        />
        <UpdateModal />
      </NativeBaseProvider>
    </AuthContext.Provider>
  );
};

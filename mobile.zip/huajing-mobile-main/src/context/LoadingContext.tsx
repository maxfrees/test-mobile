import React, { useReducer } from 'react';
import Spin from '@/components/Spin';

export type LoadingContextState = {
  loading: boolean;
};

export type ActionLoadingContextType = React.Dispatch<LoadingAction>;

type LoadingAction = {
  type: 'SHOW' | 'HIDE';
};

export type LoadingContextAction = LoadingAction;

const initialState: LoadingContextState = {
  loading: false,
};

const initialAction: ActionLoadingContextType = () => {};

export const LoadingContext =
  React.createContext<LoadingContextState>(initialState);

export const ActionLoadingContext =
  React.createContext<ActionLoadingContextType>(initialAction);

function reducer(
  state: LoadingContextState,
  action: LoadingContextAction,
): LoadingContextState {
  switch (action.type) {
    case 'SHOW':
      return { loading: true };
    case 'HIDE':
      return { loading: false };
    default:
      throw new Error();
  }
}

export const LoadingContextProvider: React.FC = ({ children }) => {
  const [state, dispatch] = useReducer(reducer, initialState);

  return (
    <ActionLoadingContext.Provider value={dispatch}>
      <LoadingContext.Provider value={{ ...state }}>
        <Spin loading={state.loading} />
        {children}
      </LoadingContext.Provider>
    </ActionLoadingContext.Provider>
  );
};

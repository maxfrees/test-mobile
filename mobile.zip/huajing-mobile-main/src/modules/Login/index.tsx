import React, { useState } from 'react';
import { TabScreen, Tabs } from '@/components/Tabs';
import InputLogin from './components/InputLogin';
import ScanLogin from './components/ScanLogin';

const TabLogin: React.FC<{ loginSuccess: () => void }> = ({ loginSuccess }) => {
  const [tabIndex, changeTabIndex] = useState(0);

  return (
    <Tabs defaultIndex={tabIndex} onChangeIndex={changeTabIndex}>
      <TabScreen label="扫码登录">
        <ScanLogin tabIndex={tabIndex} loginSuccess={loginSuccess} />
      </TabScreen>
      <TabScreen label="账户密码登录">
        <InputLogin loginSuccess={loginSuccess} />
      </TabScreen>
    </Tabs>
  );
};

export default TabLogin;

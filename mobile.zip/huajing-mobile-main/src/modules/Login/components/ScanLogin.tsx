import React, { useContext, useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Keyboard,
  NativeSyntheticEvent,
  TextInputSubmitEditingEventData,
  ToastAndroid,
} from 'react-native';
import { Input } from 'native-base';
import CommonBox from '@/components/common/CommonBox';
import useRefInput from '@/hooks/useRefInput';
import { getUniqueId } from 'react-native-device-info';
import { accountLogin, updateOperId } from '@/services/login';
import { setStorageEqpId } from '@/storage/eqpId';
import { setEqpId, setUserInfo } from '@/utils/user';
import { AuthContext } from '@/context/AuthProvider';
import { ToastMessage, responseType } from '@/utils/errorMessageMap';
import { colorPrimary } from '@/theme/theme';
import { LoginFormData } from './InputLogin';

const ScanLogin: React.FC<{ tabIndex: number; loginSuccess: () => void }> = ({
  tabIndex,
  loginSuccess,
}) => {
  const [loading, setLoading] = useState(false);

  const { delayFocus: scanCodeFocus, component: ScanCodeComponent } =
    useRefInput(Input);

  const { login } = useContext(AuthContext);

  const onOK = async ({
    nativeEvent: { text },
  }: NativeSyntheticEvent<TextInputSubmitEditingEventData>) => {
    Keyboard.dismiss();

    setLoading(true);
    try {
      const userInfo: LoginFormData = JSON.parse(text);

      // 使用ipaddress字段替代androd id
      const ipaddress = getUniqueId();
      const res = await accountLogin({
        ...userInfo,
        ipaddress: __DEV__ ? '7b1ab614a2d3f83f' : ipaddress,
        loginType: 3,
      });
      const { token, eqpid, user } = res.data;

      setStorageEqpId(eqpid);

      setEqpId(eqpid)
        .then(() => {
          setUserInfo({ ...user, eqpId: eqpid });
          login(token);
        })
        .then(() => {
          updateOperId({
            eqpId: res.data.eqpid,
            operId: res.data.user.userID,
          });
        })
        .then(() => {
          loginSuccess();
          setLoading(false);
          ToastAndroid.show(ToastMessage(res), ToastAndroid.SHORT);
        });
    } catch (error) {
      ToastAndroid.show(ToastMessage(error as responseType), ToastAndroid.LONG);
      setLoading(false);
    }
  };

  useEffect(() => {
    if (tabIndex === 0) {
      scanCodeFocus();
    }
  }, [scanCodeFocus, tabIndex]);

  return (
    <CommonBox style={{ backgroundColor: undefined }} boxProps={{ padding: 0 }}>
      {loading ? (
        <CommonBox>
          <ActivityIndicator color={colorPrimary} />
        </CommonBox>
      ) : (
        <ScanCodeComponent
          placeholder="对准条码, 按扫描枪上扫描键进行登录"
          onSubmitEditing={onOK}
        />
      )}
    </CommonBox>
  );
};

export default ScanLogin;

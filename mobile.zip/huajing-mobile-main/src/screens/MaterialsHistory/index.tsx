import React from 'react';
import { Box, Heading, Switch, Input, Spinner } from 'native-base';
import { ScrollView, View } from 'react-native';
import { IColProps } from '@/types/Table';
import TableV2 from '@/components/TableV2';
import { useRoute } from '@react-navigation/native';
import { Center } from '@/components/Center';
import useRequest from '@/hooks/useRequest';
import { getStorageEqpId } from '@/storage/eqpId';

export interface IDataSource {
  id: string;
  materialType: string;
  innerThread: string;
  materailBarCode: string;
  bondingHead: string;
  checked: 1 | 0;
  systemTime: string;
  operId: string;
}

const consumablesList: IColProps<IDataSource>[] = [
  { title: '物料类型', dataIndex: 'materialType', width: 140 },
];
const materialList: IColProps<IDataSource>[] = [
  { title: '材料类型', dataIndex: 'materialType', width: 140 },
];

const columns: IColProps<IDataSource>[] = [
  { title: '内引线规格', dataIndex: 'innerThread', width: 220 },
  {
    title: '条码',
    dataIndex: 'materailBarCode',
    width: 180,
    render: ({ value }) => {
      return <Input value={value} isDisabled />;
    },
  },
  { title: '键合头', dataIndex: 'bondingHead', width: 100 },
  { title: '系统时间', dataIndex: 'systemTime', width: 140 },
  {
    title: '是否勾选',
    dataIndex: 'checked',
    width: 100,
    render: ({ value }) => {
      return (
        <View style={{ alignItems: 'flex-start'! }}>
          <Switch
            disabled
            isChecked={value ? true : false}
            onTrackColor="blue.500"
          />
        </View>
      );
    },
  },
];
const MaterialsHistory: React.FC = () => {
  const route: {
    key: string;
    name: string;
    params: { lotId: string };
  } = useRoute();

  const eqpId = getStorageEqpId();

  const { data, isValidating } = useRequest<any>({
    url: '/tms/Materials/GetMaterialHistory',
    params: {
      eqpId: eqpId,
      lotId: route.params.lotId,
    },
  });

  if (isValidating) {
    return (
      <Box bg="white" maxWidth="100%" p={2} mt={2} rounded="lg" minHeight={200}>
        <Center>
          <Spinner color="blue.500" />
        </Center>
      </Box>
    );
  }

  return (
    <ScrollView>
      <Box rounded="lg" width="100%" p={2}>
        <Heading
          size="md"
          noOfLines={2}
          fontSize="sm"
          w={'100%'}
          paddingBottom={4}>
          耗材信息
        </Heading>
        <ScrollView horizontal>
          <TableV2
            dataSource={data?.consumables || []}
            columns={consumablesList.concat(columns)}
          />
        </ScrollView>
      </Box>
      <Box rounded="lg" width="100%" p={2}>
        <Heading
          size="md"
          noOfLines={2}
          fontSize="sm"
          w={'100%'}
          paddingBottom={4}>
          材料信息
        </Heading>
        <ScrollView horizontal>
          <TableV2
            dataSource={data?.materials || []}
            columns={materialList.concat(
              columns.filter(col => col.dataIndex !== 'innerThread'),
            )}
          />
        </ScrollView>
      </Box>
    </ScrollView>
  );
};

export default MaterialsHistory;

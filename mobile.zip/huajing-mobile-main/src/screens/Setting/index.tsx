import React, { useState } from 'react';
import { View, ToastAndroid } from 'react-native';
import { Item } from '@/components/Item';
import { AuthContext } from '@/context/AuthProvider';
import { useNavigation } from '@react-navigation/native';
import { handleCheckUpdate } from '@/services/public';
import UpdateModal from '@/components/UpdateModal';
import { responseType, ToastMessage } from '@/utils/errorMessageMap';
import CommonBox from '@/components/common/CommonBox';
import { Button } from 'native-base';
import { resetNavigate } from '@/utils/RootNavigation';

const fileJSON = require('../../../package.json');
const version = fileJSON.version;

const Setting: React.FC = () => {
  const [updateInfo, setUpdate] = useState({
    needOpen: false,
    updateURL: '',
  });

  const { logout } = React.useContext(AuthContext);

  const navigation = useNavigation();

  const handlelogOut = async () => {
    await logout();
    resetNavigate();
  };

  const settingPWD = () => {
    navigation.navigate('ForgetPwd');
  };

  const jumpQR = () => {
    navigation.navigate('PadQRCode');
  };

  const checkVersion = async () => {
    try {
      const res = await handleCheckUpdate({ version: version });
      const { isUpdate, apkUrl } = res.data;
      if (isUpdate) {
        setUpdate({
          needOpen: !!isUpdate,
          updateURL: apkUrl,
        });
      } else {
        ToastAndroid.show('已经是最新版本了', ToastAndroid.SHORT);
      }
    } catch (error) {
      ToastAndroid.show(
        `${ToastMessage(error as responseType)}`,
        ToastAndroid.LONG,
      );
    }
  };

  return (
    <CommonBox>
      <View>
        <Item title={'设备二维码'} iconName="qrcode" onPress={jumpQR} />
        <Item title={'修改登录密码'} iconName="lock" onPress={settingPWD} />
        <Item
          title={'检查更新'}
          iconName="android"
          rightDescribe={'v' + version}
          onPress={checkVersion}
        />
      </View>
      <Button onPress={handlelogOut} mt={8}>
        退出当前账号
      </Button>
      {updateInfo.needOpen && (
        <UpdateModal
          {...updateInfo}
          closeModal={() => {
            setUpdate({ needOpen: false, updateURL: '' });
          }}
        />
      )}
    </CommonBox>
  );
};
export default Setting;

import React, { useEffect, useState } from 'react';
import { View, StyleSheet, Image, ScrollView } from 'react-native';
import { HStack, Text } from 'native-base';
import { getCardPath } from '@/services/craftCard';
import { getLotInfo } from '@/services/public';
import useToast from '@/hooks/useToast';
import { responseType, ToastMessage } from '@/utils/errorMessageMap';
import { getStorageEqpId } from '@/storage/eqpId';

// const replacePrefixFile = (url: string) => {
//   return url.replace(/^file/g, 'http');
// };

// const replaceFormatToLowerCase = (url: string) => {
//   return url.replace(/(JPGE|PNG|JPG)/g, $1 => {
//     return $1.toLowerCase();
//   });
// };

interface CraftCardInfoProps {
  path: string;
  assemblyLotID: string;
}

const CraftCard: React.FC = () => {
  const [imgInfo, setImgInfo] = useState<CraftCardInfoProps>({
    path: '',
    assemblyLotID: '',
  });

  const { setShowToast } = useToast();

  useEffect(() => {
    (async () => {
      try {
        const eqpId = getStorageEqpId();

        const lotInfo = await getLotInfo({ eqpId: eqpId! });
        const cardInfo = await getCardPath({
          processCard: lotInfo.data.processCardName!,
        });
        setImgInfo({
          path: cardInfo.data,
          assemblyLotID: lotInfo.data.assemblyLotID!,
        });
      } catch (error) {
        setImgInfo({
          path: '',
          assemblyLotID: '',
        });
        setShowToast({
          type: 'error',
          message: ToastMessage(error as responseType),
        });
      }
    })();
  }, [setShowToast]);

  return (
    <ScrollView style={{ flex: 1 }}>
      <View style={styles.card}>
        <View style={styles.cardHead}>
          <HStack space={3}>
            <Text>组装批号: </Text>
            <Text>{imgInfo.assemblyLotID}</Text>
          </HStack>
        </View>
        <Image
          style={styles.image}
          source={{
            uri: `${imgInfo.path}`,
          }}
        />
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  card: {
    flex: 1,
    alignItems: 'center',
    paddingTop: 10,
  },
  cardHead: {
    width: '80%',
    flexDirection: 'row',
    paddingVertical: 20,
  },
  image: {
    width: '80%',
    height: 400,
    resizeMode: 'cover',
  },
});
export default CraftCard;

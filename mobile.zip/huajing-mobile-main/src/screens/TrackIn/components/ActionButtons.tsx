import React from 'react';
import { Box } from 'native-base';
import useToast from '@/hooks/useToast';
import { doTrackIn, useMESEqpStatus } from '@/services/trackIn';
import { responseType, ToastMessage } from '@/utils/errorMessageMap';
import { CommonActions, useNavigation } from '@react-navigation/native';
import CommonButton from '@/components/common/CommonButton';
import { getStorageEqpId } from '@/storage/eqpId';

interface IActionButtonsProps {
  lotId: string;
  trackStatus: boolean;
}

// 只有空闲和作业中可以进机
const whiteList = ['RUN', 'IDLE'];

const ActionButtons: React.FC<IActionButtonsProps> = ({
  lotId,
  trackStatus,
}) => {
  const navigation = useNavigation();

  const { setShowToast } = useToast();

  const eqpId = getStorageEqpId();

  const { data } = useMESEqpStatus(eqpId || '');

  const isDisabled =
    trackStatus || !whiteList.includes(data ? data.eqpStatus : '');

  const handleTrackIn = async () => {
    try {
      await doTrackIn({
        eqpId: eqpId || '',
        lotId: lotId,
      });
      navigation.dispatch(
        CommonActions.reset({
          index: 0,
          routes: [{ name: 'Home' }],
        }),
      );
    } catch (error) {
      setShowToast({
        type: 'error',
        message: ToastMessage(error as responseType),
      });
    }
  };

  return (
    <Box width="100%" marginBottom={5}>
      <CommonButton onPress={handleTrackIn} isDisabled={isDisabled}>
        {whiteList.includes(data?.eqpStatus ?? '')
          ? '确认进机'
          : `确认进机（仅当"RUN"/"IDLE"可进机，当前状态为 "${data?.eqpStatus}"）`}
      </CommonButton>
    </Box>
  );
};

export default ActionButtons;

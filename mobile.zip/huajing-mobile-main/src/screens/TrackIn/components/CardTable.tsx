import React, { useEffect, useState } from 'react';
import { ScrollView } from 'react-native';
import { Box, Heading, Spinner } from 'native-base';
import { getAllMaterial } from '@/services/public';
import { getEqpId } from '@/utils/user';
import { Center } from '@/components/Center';
import TableV2 from '@/components/TableV2';
import { IColProps } from '@/types/Table';
import ActionButtons from './ActionButtons';

interface consumablesProps {
  innerThread: string;
  consumablesType: string;
  consumablesDesc: string;
  consumablesBarCode: string;
}

interface materialProps {
  materialType: string;
  partNo: string;
  materialDesc: string;
  supplierNo: string;
  supplierDesc: boolean;
  materialLotNo: string;
  effectiveDate: string;
  serialNo: string;
}
// 耗材信息
const consumablesColumns: IColProps<consumablesProps>[] = [
  { title: '内引线规格', dataIndex: 'innerThread' },
  { title: '物料类型', dataIndex: 'consumablesType' },
  { title: '物料描述', dataIndex: 'consumablesDesc' },
  { title: '条码', dataIndex: 'consumablesBarCode' },
];
// 材料信息
const materialColumns: IColProps<materialProps>[] = [
  { title: '类型', dataIndex: 'materialType' },
  { title: '材料代码', dataIndex: 'partNo', width: 120 },
  { title: '供应商代码', dataIndex: 'supplierNo', width: 140 },
  { title: '供应商', dataIndex: 'supplierDesc', width: 280 },
  { title: '批号', dataIndex: 'materialLotNo' },
  { title: '有效期', dataIndex: 'effectiveDate' },
  { title: '序列号', dataIndex: 'serialNo' },
  { title: '描述', dataIndex: 'materialDesc', width: 180 },
];
const CardTable: React.FC<{
  lotId: string;
  trackStatus: 0 | 1;
}> = ({ lotId, trackStatus }) => {
  const [tables, setTables] = useState<{
    material: materialProps[];
    consumables: materialProps[];
  }>({
    material: [],
    consumables: [],
  });

  const [loading, setLoading] = useState<boolean>(false);

  useEffect(() => {
    if (lotId) {
      const initTable = async () => {
        setLoading(true);
        try {
          const eqpId = await getEqpId();
          const res = await getAllMaterial({
            eqpId: eqpId,
            lotId,
          });
          const { consumablesInfo, materialInfo } = res.data;
          setTables({
            material: materialInfo,
            consumables: consumablesInfo,
          });
          setLoading(false);
        } catch (error) {
          setTables({
            material: [],
            consumables: [],
          });
          setLoading(false);
        }
      };
      initTable();
    } else {
      setTables({
        material: [],
        consumables: [],
      });
      setLoading(false);
    }
  }, [lotId]);

  if (loading) {
    return (
      <Box bg="white" maxWidth="100%" px={2} mt={2} rounded="lg">
        <Center>
          <Spinner color="blue.500" />
        </Center>
      </Box>
    );
  }

  return (
    <>
      <Box
        bg="white"
        rounded="lg"
        width="100%"
        marginTop={5}
        marginBottom={5}
        p={2}>
        <Heading fontSize={16}>材料信息</Heading>
        <ScrollView horizontal>
          <Box w={1000}>
            <TableV2 dataSource={tables.material} columns={materialColumns} />
          </Box>
        </ScrollView>
      </Box>
      <Box bg="white" rounded="lg" width="100%" marginBottom={5} p={2}>
        <Heading fontSize={16}>耗材信息</Heading>
        <TableV2 dataSource={tables.consumables} columns={consumablesColumns} />
      </Box>
      <ActionButtons lotId={lotId} trackStatus={!!trackStatus} />
    </>
  );
};

export default CardTable;

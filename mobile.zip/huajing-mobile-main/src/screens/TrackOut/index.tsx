import React from 'react';
import { ScrollView, StyleSheet } from 'react-native';
import ActionTrackOut from './components/ActionTrackOut';

const TrackOut: React.FC = () => {
  return (
    <ScrollView style={styles.scrollView} keyboardShouldPersistTaps="handled">
      <ActionTrackOut />
    </ScrollView>
  );
};
const styles = StyleSheet.create({
  scrollView: {
    flex: 1,
  },
});
export default TrackOut;

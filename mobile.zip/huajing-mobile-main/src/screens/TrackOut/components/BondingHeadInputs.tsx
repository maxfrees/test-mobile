import React, {
  useState,
  forwardRef,
  useRef,
  useImperativeHandle,
} from 'react';
import { Input, Box, HStack, Text } from 'native-base';

const BondingHeadInputs: React.FC<{ ref: React.ForwardedRef<unknown> }> =
  forwardRef((_, ref) => {
    const [firstValue, setFirstValue] = useState('');
    const [secondValue, setSecondValue] = useState('');
    const secondInputRef = useRef({ focus: () => {} });

    const setSecondFocus = () => {
      secondInputRef.current.focus();
    };

    useImperativeHandle(ref, () => ({
      values: [firstValue, secondValue],
    }));

    return (
      <Box bg="white" rounded="lg" width="100%" marginBottom={5} p={2}>
        <HStack>
          <Text fontSize={16} color="blue.500">
            键合头(更新耗材寿命扫码键合头)
          </Text>
        </HStack>
        <HStack flexWrap="wrap" mt={6}>
          <Input
            w={180}
            h={10}
            mr={2}
            mb={2}
            value={firstValue}
            onChangeText={setFirstValue}
            onSubmitEditing={setSecondFocus}
          />
          <Input
            w={180}
            h={10}
            mr={2}
            mb={2}
            value={secondValue}
            onChangeText={setSecondValue}
            ref={secondInputRef}
          />
        </HStack>
      </Box>
    );
  });

export default BondingHeadInputs;

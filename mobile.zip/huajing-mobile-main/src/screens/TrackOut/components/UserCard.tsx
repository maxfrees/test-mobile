import React, {
  useState,
  useEffect,
  useCallback,
  forwardRef,
  useImperativeHandle,
} from 'react';
import { View, StyleSheet, Text } from 'react-native';
import { Box, Spinner, FormControl, Input, HStack, Heading } from 'native-base';
import { Center } from '@/components/Center';
import { getLotInfo } from '@/services/public';
import { getEqpId } from '@/utils/user';
import { getYieldInfo } from '@/services/trackOut';
import { IColProps } from '@/types/Table';
import { Controller, useForm } from 'react-hook-form';
import TableV2 from '@/components/TableV2';
import { TrackOutFormTypes } from './ActionTrackOut';
import { scrapProps } from './Scrap';
import InfosTable from './InfosTable';
import { responseType, ToastMessage } from '@/utils/errorMessageMap';
import useToast from '@/hooks/useToast';
import CommonBox from '@/components/common/CommonBox';
import CommonGridView from '@/components/common/CommonGrid';

export interface TrackOutProps {
  lotId?: string;
  remainingQty?: number;
  operId?: string;
  eqpId?: string;
  stepID?: string;
  assemblyLotID?: string;
  chipName?: string;
  packageType?: string;
  deviceQty?: string;
  productID?: string;
  materialBoxBarcode?: string;
  trOperID?: string;
  testedQty?: string;
  jobNum?: string;
  quotaCode?: string;
  lotHistoryId?: string;
}
interface IFormItemProps {
  label: string;
  prop: keyof TrackOutProps;
}

interface yieldProps {
  trOperID: string;
  testedQty: string;
  quotaCode: string;
}

const yieldColumns: IColProps<yieldProps>[] = [
  { title: '作业员', dataIndex: 'trOperID' },
  { title: '作业数量', dataIndex: 'testedQty' },
  { title: '定额代码', dataIndex: 'quotaCode' },
];

const formItems: IFormItemProps[] = [
  { label: '机台号', prop: 'eqpId' },
  { label: '批号', prop: 'lotId' },
  { label: '剩余数量', prop: 'remainingQty' },
  { label: '工序', prop: 'stepID' },
  { label: '组装批号', prop: 'assemblyLotID' },
  { label: '芯片名', prop: 'chipName' },
  { label: '封装形式', prop: 'packageType' },
  { label: '批次数量', prop: 'deviceQty' },
  { label: '品名', prop: 'productID' },
  { label: '料盒条码信息', prop: 'materialBoxBarcode' },
];

const BaseInfoTrackIn: React.FC<{
  scrappedList: scrapProps[];
  setLotId: (lotId: string) => void;
  ref: React.ForwardedRef<unknown>;
}> = forwardRef(({ scrappedList, setLotId }, ref) => {
  const [loading, setLoading] = useState<boolean>(false);
  // 重新赋值给父组件
  const [formValues, setFormValues] = useState<TrackOutFormTypes>({
    lotId: '',
    deviceQty: '0',
    jobNum: '0',
    lotHistoryId: '0',
    remainingQty: '0',
    knownJobs: 0,
  });
  const [yieldlSource, setYieldSource] = useState<yieldProps[]>([]);
  const { handleSubmit, control, setValue, getValues } =
    useForm<TrackOutProps>();

  const deviceQty = getValues('deviceQty');

  const { setShowToast } = useToast();

  const getLotCard = useCallback(() => {
    const initForm = async () => {
      setLoading(true);
      try {
        const eqpId = await getEqpId();
        const res = await getLotInfo({
          eqpId: eqpId,
        });
        const yieldList = await getYieldInfo({
          eqpId: eqpId,
          lotId: res.data.lotId!,
          stepID: res.data.stepID!,
        });
        setValue('eqpId', res.data.eqpId);
        setLotId(res.data.lotId!);
        for (const [key, value] of Object.entries(res.data)) {
          setValue(key as keyof TrackOutProps, value as string);
        }
        setFormValues(prevState => {
          return {
            ...prevState,
            lotId: res.data.lotId,
            deviceQty: res.data.deviceQty,
            lotHistoryId: res.data.lotHistoryId,
          };
        });

        setYieldSource(yieldList.data);
        setLoading(false);
      } catch (error) {
        setShowToast({
          type: 'error',
          message: ToastMessage(error as responseType),
        });
        setLoading(false);
      }
    };
    initForm();
  }, [setLotId, setValue, setShowToast]);

  useEffect(() => {
    getLotCard();
  }, [getLotCard]);

  useEffect(() => {
    const scrappedCount = scrappedList
      .map(v => Number(v.qty))
      .reduce((total: number, current: number) => {
        return total + current;
      }, 0);
    setValue('remainingQty', Number(deviceQty) - scrappedCount || 0);
    setFormValues(prevState => {
      return {
        ...prevState,
        remainingQty: (Number(deviceQty) - scrappedCount || 0).toString(),
      };
    });
  }, [scrappedList, setValue, deviceQty]);

  const getRemainderNums = (data: TrackOutFormTypes) => {
    const isKnownNums = yieldlSource
      .map(v => Number(v.testedQty))
      .reduce((total: number, current: number) => {
        return total + current;
      }, 0);
    setFormValues(prevState => {
      return {
        ...prevState,
        jobNum: data.jobNum,
        knownJobs: isKnownNums,
      };
    });
  };

  useImperativeHandle(ref, () => {
    // 第二个参数为init的值, 想要传递正确的参数给外界则需要重新render设置init值
    return {
      formValues: formValues,
    };
  });

  if (loading) {
    return (
      <Box bg="white" maxWidth="100%" p={2} mt={2} rounded="lg" minHeight={200}>
        <Center>
          <Spinner color="blue.500" />
        </Center>
      </Box>
    );
  }

  return (
    <>
      <CommonBox>
        <CommonGridView numOfRow={2}>
          {formItems.map(item => {
            return (
              <View style={styles.formItemLayout} key={item.label}>
                <Text
                  style={{
                    width: 90,
                    textAlign: 'left',
                  }}>
                  {item.label}:{' '}
                </Text>
                <Controller
                  control={control}
                  render={({ field: { value } }) => (
                    <Text
                      style={{
                        flex: 1,
                        flexWrap: 'wrap',
                      }}>
                      {value}
                    </Text>
                  )}
                  name={item.prop}
                />
              </View>
            );
          })}
        </CommonGridView>
      </CommonBox>
      <CommonBox style={{ paddingTop: 0 }}>
        <Heading fontSize={16}>产量信息</Heading>
        <HStack space={3} alignItems="center" mb={6}>
          <FormControl style={styles.formItem}>
            <FormControl.Label
              _text={{ color: 'muted.700', fontSize: 'sm', fontWeight: 600 }}>
              作业员
            </FormControl.Label>
            <Controller
              control={control}
              render={({ field: { value } }) => (
                <Input isDisabled value={value} />
              )}
              name="operId"
            />
          </FormControl>
          <FormControl style={styles.formItem}>
            <FormControl.Label
              _text={{ color: 'muted.700', fontSize: 'sm', fontWeight: 600 }}>
              作业数量
            </FormControl.Label>
            <Controller
              control={control}
              render={({ field: { value, onChange } }) => (
                <Input
                  keyboardType="number-pad"
                  value={value}
                  onChangeText={text => {
                    const val = text.replace(/[^0-9]/g, '');
                    onChange(val);
                  }}
                  onBlur={handleSubmit(getRemainderNums)}
                />
              )}
              name="jobNum"
            />
          </FormControl>
          <FormControl style={styles.formItem}>
            <FormControl.Label
              _text={{ color: 'muted.700', fontSize: 'sm', fontWeight: 600 }}>
              定额代码
            </FormControl.Label>
            <Controller
              control={control}
              render={({ field: { value } }) => (
                <Input isDisabled value={value} />
              )}
              name="quotaCode"
            />
          </FormControl>
        </HStack>
        <TableV2 dataSource={yieldlSource} columns={yieldColumns} />
      </CommonBox>
      {/* 两个信息表格 */}
      <InfosTable lotId={formValues.lotId!} />
    </>
  );
});

const styles = StyleSheet.create({
  formItemLayout: {
    minHeight: 40,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  formItem: {
    width: '30%',
  },
});

export default BaseInfoTrackIn;

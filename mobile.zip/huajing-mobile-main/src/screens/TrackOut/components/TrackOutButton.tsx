import React, { useState } from 'react';
import { checkIsQtyDiff, doTrackOut } from '@/services/trackOut';
import { responseType, ToastMessage } from '@/utils/errorMessageMap';
import { getEqpId } from '@/utils/user';
import { TrackOutFormTypes } from './ActionTrackOut';
import { scrapProps } from './Scrap';
import useToast from '@/hooks/useToast';
import { Button, View, Text, Modal } from 'native-base';

type IProps = {
  scrapRef: React.RefObject<{ state: scrapProps[] }>;
  defectiveRef: React.RefObject<{ state: scrapProps[] }>;
  userWriteRef: React.MutableRefObject<{
    formValues: TrackOutFormTypes;
  }>;
  autoInputRef: React.RefObject<{ values: String[] }>;
  // bondingHeadRef: React.RefObject<{values: String[]}>;
};

const TrackOutButton: React.FC<IProps> = ({
  scrapRef,
  defectiveRef,
  userWriteRef,
  autoInputRef,
  // bondingHeadRef,
}) => {
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isDisabled, setDisabled] = useState<boolean>(false);

  const { setShowToast } = useToast();

  const validNums: () => boolean = () => {
    // 报废数量
    const scrapNum = (scrapRef.current!.state || [])
      .map(v => Number(v.qty))
      .reduce((total: number, current: number) => {
        return total + current;
      }, 0);
    // 次品数量
    const defectiveNum = (defectiveRef.current!.state || [])
      .map(v => Number(v.qty))
      .reduce((total: number, current: number) => {
        return total + current;
      }, 0);
    const { jobNum, deviceQty, knownJobs } = userWriteRef.current.formValues;

    if (Number(jobNum) + Number(knownJobs) > Number(deviceQty)) {
      setShowToast({
        type: 'error',
        message: '作业总数有误',
      });
      return false;
    } else if (scrapNum > Number(deviceQty)) {
      setShowToast({
        type: 'error',
        message: '报废数量有误',
      });
      return false;
    } else if (defectiveNum > Number(deviceQty)) {
      setShowToast({
        type: 'error',
        message: '次品数量有误',
      });
      return false;
    } else if (
      scrapNum + defectiveNum + Number(jobNum) + Number(knownJobs) !==
      Number(deviceQty)
    ) {
      setShowToast({
        type: 'error',
        message: '总数计算有误',
      });
      return false;
    }
    return scrapNum + defectiveNum + Number(jobNum) + Number(knownJobs) ===
      Number(deviceQty)
      ? true
      : false;
  };

  const trackInSucc = async () => {
    setIsLoading(true);
    try {
      const eqpId = await getEqpId();
      const res = await doTrackOut({
        lotHistoryId: userWriteRef.current.formValues.lotHistoryId,
        eqpId: eqpId,
        lotId: userWriteRef.current.formValues.lotId,
        remainingQty: userWriteRef.current.formValues.remainingQty,
        jobNum: userWriteRef.current.formValues.jobNum,
        scrapList: scrapRef.current!.state,
        defectiveList: defectiveRef.current!.state,
        boxs: autoInputRef.current!.values.join(','),
        // headList: bondingHeadRef.current?.values,
      });
      setShowToast({
        type: 'success',
        message: ToastMessage(res),
      });
      setIsLoading(false);
      setDisabled(true);
    } catch (error) {
      setShowToast({
        type: 'error',
        message: ToastMessage(error as responseType),
      });
      setIsLoading(false);
      setDisabled(false);
    }
  };
  const [showModal, setShowModal] = useState(false);

  const handleCheckIsQtyDiff = async () => {
    setIsLoading(true);
    try {
      const eqpId = await getEqpId();
      const res = await checkIsQtyDiff({
        eqpId: eqpId,
        lotId: userWriteRef.current.formValues.lotId,
      });
      if (res.data) {
        setShowModal(true);
      } else {
        trackInSucc();
      }
      setIsLoading(false);
      setDisabled(true);
    } catch (error) {
      setShowToast({
        type: 'error',
        message: ToastMessage(error as responseType),
      });
      setIsLoading(false);
      setDisabled(false);
    }
  };

  const validBox: () => boolean = () => {
    if (!autoInputRef.current!.values.length) {
      setShowToast({
        type: 'error',
        message: '料盒信息填写至少一个',
      });
      return false;
    } else {
      return true;
    }
  };

  const handleTrackIn = () => {
    validNums() && validBox() && handleCheckIsQtyDiff();
  };

  const QtyDiffWidget = () => {
    return (
      <Modal isOpen={showModal} onClose={() => setShowModal(false)}>
        <Modal.Content maxWidth="400px">
          <Modal.Body>
            <Text>实际生产跟开批数量不符（超过2%）</Text>
          </Modal.Body>
          <Modal.Footer>
            <Button
              flex="1"
              onPress={() => {
                setShowModal(false);
                trackInSucc();
              }}>
              OK
            </Button>
          </Modal.Footer>
        </Modal.Content>
      </Modal>
    );
  };

  return (
    <View>
      <Button
        _loading={{
          bg: 'blue.500',
          _text: {
            color: '#FFFFFF',
          },
        }}
        isDisabled={isDisabled}
        onPress={handleTrackIn}
        isLoading={isLoading}>
        确认出机
      </Button>
      <QtyDiffWidget />
    </View>
  );
};

export default TrackOutButton;

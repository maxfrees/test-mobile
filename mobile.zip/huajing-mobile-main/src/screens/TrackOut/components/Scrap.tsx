import { Box, Heading, Input, Select, Pressable, Text } from 'native-base';
import React, {
  useState,
  useEffect,
  useImperativeHandle,
  forwardRef,
} from 'react';
import { getOEEReason } from '@/services/OEESwitch';
import { useForm, Controller, SubmitHandler } from 'react-hook-form';
import TableV2 from '@/components/TableV2';
import { IColProps } from '@/types/Table';
import { ToastMessage, responseType } from '@/utils/errorMessageMap';
import useToast from '@/hooks/useToast';
import CommonBox from '@/components/common/CommonBox';
import CommonButton from '@/components/common/CommonButton';

export interface scrapProps {
  qty: string;
  reason: string;
}
const Scrap: React.FC<{
  type: '次品数量' | '报废数量';
  lotId: string;
  addScrapped?: (list: scrapProps[]) => void;
  ref: React.ForwardedRef<unknown>;
}> = forwardRef(({ type, addScrapped, lotId }, ref) => {
  const [scrapSource, setScrapSource] = useState<scrapProps[]>([]);
  const [reasonList, setreasonList] = useState<{ id: string; name: string }[]>(
    [],
  );
  const { control, handleSubmit, setValue } = useForm<scrapProps>();

  const { setShowToast } = useToast();

  // 报废信息
  const scrapColumns: IColProps<scrapProps>[] = [
    { title: type, dataIndex: 'qty' },
    { title: '原因代码', dataIndex: 'reason' },
    {
      title: '操作',
      dataIndex: '',
      render: (field, _handleSubmit, _setValue, $index) => {
        return (
          <Pressable onPress={() => handleDelete($index)}>
            <Text color="blue.500" p={2}>
              删除
            </Text>
          </Pressable>
        );
      },
    },
  ];

  useImperativeHandle(ref, () => ({
    state: scrapSource,
  }));

  const onSubmit: SubmitHandler<scrapProps> = data => {
    if (data.qty && data.reason) {
      // 2022/04/20 再改回来, 不用传name
      // const findItem = reasonList.find(item => item.id === data.reason);

      setScrapSource(prevState => {
        return prevState.concat([
          {
            qty: data.qty,
            reason: data.reason,
          },
        ]);
      });
      setValue('qty', '');
      setValue('reason', '');

      addScrapped &&
        addScrapped(
          scrapSource.concat([
            {
              qty: data.qty,
              reason: data.reason,
            },
          ]),
        );
    } else {
      setShowToast({
        type: 'error',
        message: '报废数量和原因代码请填写完整',
      });
    }
  };

  const handleDelete = (index: number) => {
    const newScrapSource = [...scrapSource];
    newScrapSource.splice(index, 1);
    setScrapSource(newScrapSource);
    addScrapped && addScrapped(newScrapSource);
  };

  useEffect(() => {
    const getReasonList = async () => {
      try {
        const res = await getOEEReason({
          statusCode: '',
          type: 3,
          lotId: lotId,
        });
        if (Array.isArray(res.data) && res.code === 1) {
          setreasonList(res.data);
        } else {
          setShowToast({
            type: 'success',
            message: ToastMessage(res),
          });
        }
      } catch (error) {
        setShowToast({
          type: 'error',
          message: ToastMessage(error as responseType),
        });
      }
    };
    if (lotId) {
      getReasonList();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lotId]);

  return (
    <CommonBox style={{ paddingTop: 0 }}>
      <Heading fontSize={16} mb={4}>
        {type}
      </Heading>
      <Box flexDirection="row" justifyContent="center" alignItems="center">
        <Box w={200}>
          <Controller
            control={control}
            render={({ field: { onChange, value } }) => (
              <Input
                placeholder={'请输入' + type}
                onChangeText={text => {
                  const val = text.replace(/[^0-9]/g, '');
                  onChange(val);
                }}
                value={value}
                keyboardType="numeric"
              />
            )}
            name="qty"
          />
        </Box>
        <Box w={200} ml={6}>
          <Controller
            control={control}
            render={({ field: { onChange, value } }) => (
              <Select
                isDisabled={!reasonList?.length}
                placeholder="请选择原因代码"
                selectedValue={value}
                onValueChange={(itemValue: string) => onChange(itemValue)}
                _selectedItem={{
                  bg: 'info.100',
                }}>
                {reasonList.map(v => {
                  return <Select.Item label={v.name} value={v.id} key={v.id} />;
                })}
              </Select>
            )}
            name="reason"
          />
        </Box>
        {/* <LoadingButton
          title="新增"
          onPress={handleSubmit(onSubmit)}
          w={100}
          ml={6}
          size="lg"
        /> */}
        <CommonButton
          style={{ marginLeft: 12 }}
          onPress={handleSubmit(onSubmit)}>
          新增
        </CommonButton>
      </Box>
      <TableV2 dataSource={scrapSource} columns={scrapColumns} />
    </CommonBox>
  );
});

export default Scrap;

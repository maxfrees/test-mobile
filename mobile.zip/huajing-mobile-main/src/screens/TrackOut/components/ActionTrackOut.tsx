import React, { useRef, useState } from 'react';
import { HStack, Text } from 'native-base';
import Scrap, { scrapProps } from './Scrap';
import AutoInputs from '@/components/AutoInputs';
// import BondingHeadInputs from './BondingHeadInputs';
import UserCard from './UserCard';
import TrackInButton from './TrackOutButton';
import CommonBox from '@/components/common/CommonBox';

export interface TrackOutFormTypes {
  lotId?: string;
  deviceQty?: string;
  jobNum?: string;
  lotHistoryId?: string;
  remainingQty?: string;
  knownJobs?: number;
}

const CardTable: React.FC = () => {
  // 通过各种绑定ref来获取 FC 内部的参数
  const userWriteRef = useRef<{ formValues: TrackOutFormTypes }>({
    formValues: {},
  });
  const scrapRef = useRef<{ state: scrapProps[] }>(null);
  const defectiveRef = useRef<{ state: scrapProps[] }>(null);
  // const bondingHeadInputsRef = useRef<{values: String[]}>(null);
  const autoInputRef = useRef<{ values: String[] }>(null);

  const [scrappedList, setScrappedList] = useState<scrapProps[]>([]);
  const [lotId, setLotId] = useState<string>('');

  const getScrappedList = (list: scrapProps[]) => {
    setScrappedList(list);
  };

  return (
    <>
      <UserCard
        ref={userWriteRef}
        scrappedList={scrappedList}
        setLotId={setLotId}
      />
      <CommonBox style={{ paddingTop: 0 }}>
        <HStack>
          <Text fontSize={16} color="blue.500">
            料盒信息
          </Text>
          <Text fontSize={16} color="red.600" pl={1}>
            *
          </Text>
        </HStack>
        <HStack flexWrap="wrap" mt={6}>
          <AutoInputs ref={autoInputRef} />
        </HStack>
      </CommonBox>
      {/* <BondingHeadInputs ref={bondingHeadInputsRef} /> */}
      <Scrap
        type="报废数量"
        ref={scrapRef}
        lotId={lotId}
        addScrapped={getScrappedList}
      />
      <Scrap type="次品数量" ref={defectiveRef} lotId={lotId} />
      <CommonBox style={{ paddingTop: 0 }} boxProps={{ padding: 0 }}>
        <TrackInButton
          scrapRef={scrapRef}
          // bondingHeadRef={bondingHeadInputsRef}
          defectiveRef={defectiveRef}
          userWriteRef={userWriteRef}
          autoInputRef={autoInputRef}
        />
      </CommonBox>
    </>
  );
};

export default CardTable;

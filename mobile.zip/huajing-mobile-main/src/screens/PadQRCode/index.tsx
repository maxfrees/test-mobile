import React from 'react';
import { Center, Text } from 'native-base';
import QRCode from 'react-qr-code';
import { getUniqueId } from 'react-native-device-info';

const PadQRCode: React.FC = () => {
  const uniqueId = getUniqueId();

  return (
    <Center flex={1}>
      <Center
        height={400}
        width={{
          base: 400,
          lg: 400,
        }}>
        <Text italic py={8}>
          设备条码: <Text bold>{uniqueId}</Text>
        </Text>
        <QRCode value={uniqueId} />
      </Center>
    </Center>
  );
};

export default PadQRCode;

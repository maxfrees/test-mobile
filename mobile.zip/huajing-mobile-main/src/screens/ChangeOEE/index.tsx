import React, { useContext, useEffect, useState } from 'react';
import {
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  View,
  ToastAndroid,
} from 'react-native';
import { Input, Select, TextArea, Text, FormControl } from 'native-base';
import { useForm, Controller, SubmitHandler } from 'react-hook-form';
import {
  getOEEStatusSwitch,
  getOEEReason,
  doUpdate,
} from '@/services/OEESwitch';
import useToast from '@/hooks/useToast';
import { responseType, ToastMessage } from 'src/utils/errorMessageMap';
import { CommonActions, useNavigation } from '@react-navigation/native';
import CommonButton from '@/components/common/CommonButton';
import CommonBox from '@/components/common/CommonBox';
import { getStorageEqpId } from '@/storage/eqpId';
import { ActionLoadingContext } from '@/context/LoadingContext';
import { getMESEqpStatusByEQPName } from '@/services/trackIn';

export interface OEEForm {
  eqpId: string;
  lotId: string;
  eqpStatus: string;
  operId: string;
  reasonCode: string;
  eqpSwitchStatus: string;
  remark: string;
}

interface SelectListModel {
  id: string;
  name: string;
}

const ChangeOEE: React.FC = () => {
  const navigation = useNavigation();

  const { setShowToast } = useToast();

  const dispatch = useContext(ActionLoadingContext);

  const eqpId = getStorageEqpId();

  const [statusSelectList, setStatusSelectList] = useState<SelectListModel[]>(
    [],
  );
  const [reasonCodeSelectList, setReasonCodeSelectList] = useState<
    SelectListModel[]
  >([]);

  const {
    handleSubmit,
    control,
    getValues,
    reset,
    formState: { errors },
  } = useForm<OEEForm>();

  useEffect(() => {
    const init = async () => {
      dispatch({ type: 'SHOW' });
      try {
        const res = await getOEEStatusSwitch({ eqpId: eqpId || '' });
        const eqpStatus = await getMESEqpStatusByEQPName({
          eqpId: eqpId || '',
        });

        const { statusList, ...obj } = res.data;
        setStatusSelectList(statusList || []);
        reset({
          ...obj,
          eqpStatus: eqpStatus.data.eqpStatus,
        });
      } catch (error) {
        setShowToast({
          type: 'error',
          message: ToastMessage(error as responseType),
        });
      } finally {
        dispatch({ type: 'HIDE' });
      }
    };
    init();
  }, [setShowToast, reset, eqpId, dispatch]);

  const getReasonCodeList = async (value: string) => {
    try {
      const lotId = getValues('lotId');
      const res = await getOEEReason({
        statusCode: value,
        type: 1,
        lotId: lotId,
      });
      setReasonCodeSelectList(res.data);
    } catch (error) {
      setShowToast({
        type: 'error',
        message: ToastMessage(error as responseType),
      });
    }
  };

  const onSubmit: SubmitHandler<OEEForm> = async data => {
    try {
      const res = await doUpdate(data);
      navigation.dispatch(
        CommonActions.reset({
          index: 0,
          routes: [{ name: 'Home' }],
        }),
      );
      ToastAndroid.show(ToastMessage(res), ToastAndroid.SHORT);
    } catch (error) {
      setShowToast({
        type: 'error',
        message: ToastMessage(error as responseType),
      });
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      style={{ flex: 1 }}>
      <ScrollView style={styles.layout}>
        <CommonBox>
          <FormControl>
            <FormControl.Label>设备编号: </FormControl.Label>
            <Controller
              control={control}
              render={({ field: { value } }) => (
                <Input w="100%" value={value} isDisabled />
              )}
              name="eqpId"
            />
          </FormControl>
          <FormControl>
            <FormControl.Label>机台状态: </FormControl.Label>
            <Controller
              control={control}
              render={({ field: { value } }) => (
                <Input w="100%" value={value} isDisabled />
              )}
              name="eqpStatus"
            />
          </FormControl>
          <FormControl isRequired isInvalid={!!errors.eqpSwitchStatus?.message}>
            <FormControl.Label>状态: </FormControl.Label>
            <Controller
              control={control}
              rules={{ required: '请选择状态' }}
              render={({ field: { onChange, value } }) => (
                <Select
                  w="100%"
                  selectedValue={value}
                  onValueChange={(itemValue: string) => {
                    onChange(itemValue);
                    getReasonCodeList(itemValue);
                  }}
                  _selectedItem={{
                    bg: 'info.100',
                  }}>
                  {statusSelectList.map(item => (
                    <Select.Item
                      label={item.name}
                      value={item.id}
                      key={item.id}
                    />
                  ))}
                </Select>
              )}
              name="eqpSwitchStatus"
            />
            <FormControl.ErrorMessage>
              {errors.eqpSwitchStatus?.message}
            </FormControl.ErrorMessage>
          </FormControl>
          <FormControl isRequired isInvalid={'reasonCode' in errors}>
            <FormControl.Label>原因代码: </FormControl.Label>
            <Controller
              control={control}
              rules={{ required: '请选择原因代码' }}
              render={({ field: { onChange, value } }) => (
                <Select
                  w="100%"
                  isDisabled={!reasonCodeSelectList?.length}
                  selectedValue={value}
                  onValueChange={(itemValue: string) => {
                    onChange(itemValue);
                  }}
                  _selectedItem={{
                    bg: 'info.100',
                  }}>
                  {reasonCodeSelectList.map(item => (
                    <Select.Item
                      label={item.name}
                      value={item.id}
                      key={item.id}
                    />
                  ))}
                </Select>
              )}
              name="reasonCode"
            />
            <FormControl.ErrorMessage>
              {errors.reasonCode?.message}
            </FormControl.ErrorMessage>
          </FormControl>
          <FormControl>
            <FormControl.Label>操作员: </FormControl.Label>
            <Controller
              control={control}
              render={({ field: { value } }) => (
                <Input w="100%" value={value} isDisabled />
              )}
              name="operId"
            />
          </FormControl>
          <FormControl isInvalid={'remark' in errors}>
            <FormControl.Label>备注: </FormControl.Label>
            <Controller
              control={control}
              rules={{ maxLength: 200 }}
              render={({ field: { onChange, value } }) => (
                <TextArea
                  w="100%"
                  value={value}
                  onChangeText={onChange}
                  InputRightElement={
                    <View style={styles.textArea}>
                      <Text color="muted.300">{`${
                        value ? value.length : 0
                      }/200`}</Text>
                    </View>
                  }
                />
              )}
              name="remark"
            />
          </FormControl>
        </CommonBox>
        <CommonBox style={{ paddingTop: 0 }} boxProps={{ padding: 0 }}>
          <CommonButton onPress={handleSubmit(onSubmit)}>确认</CommonButton>
        </CommonBox>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  layout: {
    flex: 1,
  },
  textArea: {
    position: 'absolute',
    right: 10,
    bottom: 0,
  },
});
export default ChangeOEE;

import React from 'react';
import { UIManager, Platform, ScrollView, StyleSheet } from 'react-native';
import MoreFeatures from './components/MoreFeatures';
import UserCard from './components/UserCard';
import MessageBox from './components/MessageBox';
import ClearLotButton from './components/ClearLotButton';
import { headerStyle } from '@/theme/navigatorStyles';
import { createStackNavigator } from '@react-navigation/stack';

if (Platform.OS === 'android') {
  if (UIManager.setLayoutAnimationEnabledExperimental) {
    UIManager.setLayoutAnimationEnabledExperimental(true);
  }
}

const Home: React.FC = () => {
  return (
    <ScrollView style={styles.container}>
      <UserCard />
      <MessageBox />
      <ClearLotButton />
      <MoreFeatures />
    </ScrollView>
  );
};

const HomeScreen: React.FC = () => {
  const Stack = createStackNavigator();
  return (
    <Stack.Navigator>
      <Stack.Screen
        name="My"
        component={Home}
        options={{
          headerTitle: 'ATMS',
          headerTitleAlign: 'left',
          ...headerStyle,
        }}
      />
    </Stack.Navigator>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});
export default HomeScreen;

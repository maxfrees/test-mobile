import React, { useState, useContext, useCallback } from 'react';
import { View, StyleSheet, Text } from 'react-native';
import { getLotInfo } from '@/services/public';
import { getEqpId } from '@/utils/user';
import { AuthContext } from '@/context/AuthProvider';
import { useFocusEffect } from '@react-navigation/native';
import CommonGridView from '@/components/common/CommonGrid';
import CommonBox from '@/components/common/CommonBox';

interface IUserFormProps {
  operId?: string;
  eqpId?: string;
  lotId?: string;
  stepID?: string;
  trackStatus?: string;
  assemblyLotID?: string;
  chipName?: string;
  packageType?: string;
  deviceQty?: string;
  cleaver?: string;
  wireGuideTube?: string;
  productID?: string;
  loopCutter?: string;
}

interface FormTypes {
  label: string;
  prop: keyof IUserFormProps;
}

const formItem: FormTypes[] = [
  { label: '作业员', prop: 'operId' },
  { label: '机台号', prop: 'eqpId' },
  // {label: '批号', prop: 'lotId'},
  { label: '品名', prop: 'productID' },
  { label: '工序', prop: 'stepID' },
  { label: '当前状态', prop: 'trackStatus' },
  { label: '组装批号', prop: 'assemblyLotID' },
  { label: '芯片名', prop: 'chipName' },
  { label: '封装形式', prop: 'packageType' },
  { label: '批次数量', prop: 'deviceQty' },
  { label: '劈刀理论寿命点数', prop: 'cleaver' },
  { label: '导丝管理论寿命点数', prop: 'wireGuideTube' },
  { label: '切刀', prop: 'loopCutter' },
];

const UserCard: React.FC = () => {
  const [userInfo, setUserInfo] = useState<IUserFormProps>({});
  const { setLotInfo, changeLoginStatus, isHandOver } = useContext(AuthContext);

  const getCardInfo = useCallback(() => {
    const initInfo = async () => {
      try {
        const eqpId = await getEqpId();
        const res = await getLotInfo({
          eqpId: eqpId,
          trackInPage: 1,
        });
        setUserInfo({
          ...res.data,
          trackStatus: res.data.trackStatus ? '已开批' : '未开批',
        });
        setLotInfo(res.data);
        changeLoginStatus(true);
      } catch (error) {
        setUserInfo({});
        setLotInfo({});
        changeLoginStatus(false);
      }
    };
    if (isHandOver) {
      setUserInfo(prevState => {
        return {
          ...prevState,
          operId: '',
        };
      });
    } else {
      initInfo();
    }
  }, [setLotInfo, changeLoginStatus, isHandOver]);

  useFocusEffect(getCardInfo);

  return (
    <CommonBox>
      <CommonGridView numOfRow={2}>
        {formItem.map(item => {
          return (
            <View style={styles.cardItem} key={item.label}>
              <Text style={styles.cardItemTitle}>{item.label} : </Text>
              <Text style={styles.cardItemContent}>{userInfo[item.prop]}</Text>
            </View>
          );
        })}
      </CommonGridView>
    </CommonBox>
  );
};

const styles = StyleSheet.create({
  cardItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  cardItemTitle: {
    width: '46%',
    textAlign: 'left',
  },
  cardItemContent: {
    width: '50%',
    flexWrap: 'wrap',
  },
});
export default UserCard;

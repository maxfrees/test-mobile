import React, { useEffect, useState, useContext } from 'react';
import LoadingButton from '@/components/LoadingButton';
import CommonBox from '@/components/common/CommonBox';
import { checkAuthority, clearEAPLotInfo } from '@/services/public';
import { getUserInfo } from '@/utils/user';
import { getEqpId } from '@/utils/user';
import { ToastMessage, responseType } from '@/utils/errorMessageMap';
import useToast from '@/hooks/useToast';
import { AuthContext } from '@/context/AuthProvider';
import { resetNavigate } from '@/utils/RootNavigation';

const ClearLotButton: React.FC = () => {
  const { lotForm } = useContext(AuthContext);

  const [hasAuth, setAuth] = useState<boolean>(false);

  const { setShowToast } = useToast();

  const onClear = async () => {
    try {
      const eqpId = await getEqpId();
      const { userID } = await getUserInfo();

      const res = await clearEAPLotInfo({
        eqpId: eqpId,
        testerId: userID,
        lotId: lotForm.lotId!,
      });
      setShowToast({
        type: 'success',
        message: ToastMessage(res),
      });
      resetNavigate();
    } catch (error) {
      setShowToast({
        type: 'error',
        message: ToastMessage(error as responseType),
      });
    }
  };

  useEffect(() => {
    (async () => {
      try {
        const userInfo = await getUserInfo();

        const res = await checkAuthority({
          userName: userInfo.userName,
          roleName: 'CLEARLOT',
        });
        setAuth(res.data);
      } catch (error) {
        setAuth(false);
      }
    })();
  }, []);

  if (!hasAuth) {
    return null;
  }

  return (
    <CommonBox style={{ paddingTop: 0 }}>
      <LoadingButton title="清除Lot信息" onPress={onClear} />
    </CommonBox>
  );
};

export default ClearLotButton;

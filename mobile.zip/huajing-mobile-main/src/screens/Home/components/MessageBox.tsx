import React, { useEffect, useRef, useState } from 'react';
import { ScrollView, View, StyleSheet } from 'react-native';
import { Text } from 'native-base';
import { parseTime } from '@/utils/parseTime';
import { getEqpId } from '@/utils/user';
import CommonBox from '@/components/common/CommonBox';

type SocketType = {
  eqpId: string;
  functionName: string;
  body: {
    message?: string;
    type?: string;
    action?: string;
    status?: string;
  };
};

type MessageType = {
  date: string;
  message: string;
  type: string;
};

const ITEM_H = 40; // 每项的高度

const WSUrl = __DEV__
  ? 'ws://10.100.10.53:8070/ws/WebSocket/Connection'
  : //'ws://10.100.101.22:8070/ws/WebSocket/Connection';
    'ws://192.168.20.8:8070/ws/WebSocket/Connection';

const Item = ({ item }: { item: MessageType }) => {
  return (
    <View style={styles.messageItem}>
      <Text style={styles.messageDate}>{item.date}</Text>
      <Text style={styles.messageTitle} noOfLines={1}>
        {item.message}
      </Text>
    </View>
  );
};

const MessageBox: React.FC = () => {
  const ws = useRef<WebSocket>();
  const timerID = useRef<NodeJS.Timeout | null>(null);
  const [scrollMessage, setScrollMessage] = useState<MessageType[]>([]);

  const keepAlive = () => {
    const timeout = 20000;
    if (ws.current?.readyState === WebSocket.OPEN) {
      ws.current.send('');
    }
    timerID.current = setTimeout(keepAlive, timeout);
  };

  const closeWebSocket = () => {
    ws.current?.close(1000);
    cancelKeepAlive();
  };

  const cancelKeepAlive = () => {
    if (timerID.current) {
      clearTimeout(timerID.current);
    }
  };

  useEffect(() => {
    (async () => {
      try {
        const eqpid = await getEqpId();
        if (ws.current?.readyState === 1) {
          ws.current = undefined;
        }
        ws.current = new WebSocket(WSUrl + `?eqpid=${eqpid}`);
        ws.current.onerror = e => {
          console.log('error', e);
          // closeWebSocket();
        };
        ws.current.onclose = e => {
          console.log('close', e);
          closeWebSocket();
        };
        ws.current.onopen = () => {
          console.log('open');
          keepAlive();
        };
        ws.current.onmessage = (event: WebSocketMessageEvent) => {
          const msg = event.data ? JSON.parse(event.data) : '';
          console.log(msg, '<---- 接受到的消息');
          if (!msg) {
            return;
          }
          const { functionName, body } = msg as SocketType;
          if (functionName === 'EAPToOUI_ShowUIMessage') {
            const msgItem: MessageType = {
              type: body.type!,
              message: body.message!,
              date: parseTime(new Date().getTime())!,
            };
            setScrollMessage(preState => [msgItem].concat(preState));
          }
        };
      } catch (error) {}
    })();
    return () => {
      ws.current = undefined;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <CommonBox style={{ height: 200, paddingTop: 0 }}>
      <View style={styles.messageContent}>
        <ScrollView horizontal>
          <View style={styles.messageWrap}>
            {scrollMessage.map(item => (
              <Item item={item} key={item.date + item.message} />
            ))}
          </View>
        </ScrollView>
      </View>
    </CommonBox>
  );
};

const styles = StyleSheet.create({
  messageContent: {
    width: '100%',
    height: '100%',
    backgroundColor: '#fff',
    borderRadius: 8,
  },
  messageWrap: {
    paddingHorizontal: 10,
  },
  messageItem: {
    marginHorizontal: 10,
    flexDirection: 'row',
  },
  messageDate: {
    height: ITEM_H,
    lineHeight: ITEM_H,
    textAlign: 'left',
    paddingRight: 20,
  },
  messageTitle: {
    width: '100%',
    height: ITEM_H,
    lineHeight: ITEM_H,
    textAlign: 'left',
  },
});
export default MessageBox;

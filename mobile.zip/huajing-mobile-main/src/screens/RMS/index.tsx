import React, { useEffect, useCallback } from 'react';
import { Linking } from 'react-native';
import { View } from 'native-base';
import { CommonActions, useNavigation } from '@react-navigation/native';
const RMSWebView: React.FC = () => {
  const navigation = useNavigation();
  const OpenURL = useCallback(async () => {
    const supported = await Linking.canOpenURL('http://192.168.20.8:8080/');
    if (supported) {
      await Linking.openURL('http://192.168.20.8:8080/');
      navigation.dispatch(
        CommonActions.reset({
          index: 0,
          routes: [{ name: 'Home' }],
        }),
      );
    }
  }, [navigation]);

  useEffect(() => {
    OpenURL();
  }, [OpenURL]);

  return <View flex={1} />;
};

export default RMSWebView;

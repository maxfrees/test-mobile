import React, { useState, useEffect } from 'react';
import {
  NativeSyntheticEvent,
  ScrollView,
  TextInputSubmitEditingEventData,
  View,
  KeyboardAvoidingView,
  Platform,
  StyleSheet,
} from 'react-native';
import {
  HStack,
  Text,
  Input,
  Select,
  VStack,
  FormControl,
  TextArea,
} from 'native-base';
import ShowInfoTable from './components/TheInfosTable';
import { useForm, Controller, SubmitHandler } from 'react-hook-form';
import { doStop } from '@/services/operationStop';
import { getOEEReason } from '@/services/OEESwitch';
import { getLotInfo } from '@/services/public';
import { responseType, ToastMessage } from '@/utils/errorMessageMap';
import useToast from '@/hooks/useToast';
import { getStorageEqpId } from '@/storage/eqpId';
import CommonBox from '@/components/common/CommonBox';
import CommonButton from '@/components/common/CommonButton';

interface IInputProps {
  render: (
    eventKeyDown: (
      e: NativeSyntheticEvent<TextInputSubmitEditingEventData>,
    ) => void,
  ) => JSX.Element;
}

interface DiscontinueForm {
  reason: string;
  remark: string;
}

const Discontinue: React.FC = () => {
  const [inputs, setinputs] = useState<IInputProps[]>([
    {
      render: eventKeyDown => {
        return (
          <Input
            w={180}
            onSubmitEditing={eventKeyDown}
            blurOnSubmit={true}
            mr={2}
            mb={2}
          />
        );
      },
    },
  ]);
  const { setShowToast } = useToast();

  const [materialBox, setMaterialBox] = useState<string[]>([]);

  const [reasonList, setReasonList] = useState<{ id: string; name: string }[]>(
    [],
  );
  const [isDisabled, setDisabled] = useState<boolean>(false);

  const [lotId, setLotId] = useState('');

  const eqpId = getStorageEqpId() as string;

  const {
    handleSubmit,
    control,
    formState: { errors },
  } = useForm<DiscontinueForm>();

  const onSubmit: SubmitHandler<DiscontinueForm> = async data => {
    if (materialBox.length) {
      try {
        const res = await doStop({
          eqpId,
          lotId: lotId,
          boxs: materialBox.join(','),
          ...data,
        });
        setDisabled(true);
        setShowToast({
          type: 'success',
          message: ToastMessage(res),
        });
      } catch (error) {
        setShowToast({
          type: 'error',
          message: ToastMessage(error as responseType),
        });
      }
    } else {
      setDisabled(false);
      setShowToast({
        type: 'error',
        message: '料盒信息填写至少一个',
      });
    }
  };
  const handleKeyDown = (
    e: NativeSyntheticEvent<TextInputSubmitEditingEventData>,
  ) => {
    if (e.nativeEvent.text && !materialBox.includes(e.nativeEvent.text)) {
      setMaterialBox(materialBox.concat(e.nativeEvent.text));
      setinputs(
        inputs.concat([
          {
            render: eventKeyDown => {
              return (
                <Input
                  w={180}
                  onSubmitEditing={eventKeyDown}
                  blurOnSubmit={true}
                  autoFocus
                  mr={2}
                  mb={2}
                />
              );
            },
          },
        ]),
      );
    } else if (e.nativeEvent.text && materialBox.includes(e.nativeEvent.text)) {
      setShowToast({
        type: 'success',
        message: '料盒重复添加',
      });
    }
  };

  useEffect(() => {
    const init = async () => {
      try {
        const res = await getLotInfo({ eqpId });
        const reasonData = await getOEEReason({
          statusCode: '',
          type: 2,
          lotId: res.data.lotId || '',
        });
        setReasonList(Array.isArray(reasonData.data) ? reasonData.data : []);
        setLotId(res.data.lotId!);
      } catch (error) {
        setShowToast({
          type: 'error',
          message: ToastMessage(error as responseType),
        });
      }
    };
    init();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [eqpId]);

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      style={styles.scrollView}>
      <ScrollView keyboardShouldPersistTaps="handled" style={styles.scrollView}>
        <CommonBox>
          <HStack space={3} p={2}>
            <Text>作业批号: </Text>
            <Text>{lotId}</Text>
          </HStack>
        </CommonBox>
        <ShowInfoTable lotId={lotId} />
        <CommonBox style={{ paddingTop: 0 }}>
          <HStack>
            <Text fontSize={16} color="blue.500">
              料盒信息
            </Text>
            <Text fontSize={16} color="red.600" pl={1}>
              *
            </Text>
          </HStack>
          <HStack flexWrap="wrap" mt={6}>
            {inputs.map((item, index) => {
              return <View key={index}>{item.render(handleKeyDown)}</View>;
            })}
          </HStack>
        </CommonBox>
        <CommonBox style={{ paddingTop: 0 }}>
          <VStack width="100%" space={4} alignItems="center" mb={2}>
            <FormControl isRequired isInvalid={'reason' in errors}>
              <FormControl.Label>原因: </FormControl.Label>
              <Controller
                control={control}
                rules={{ required: '请选择原因' }}
                render={({ field: { onChange, value } }) => (
                  <Select
                    w="100%"
                    isDisabled={!reasonList?.length}
                    selectedValue={value}
                    onValueChange={(itemValue: string) => {
                      onChange(itemValue);
                    }}
                    _selectedItem={{
                      bg: 'info.100',
                    }}>
                    {reasonList.map(item => (
                      <Select.Item
                        mt={1}
                        label={item.name}
                        value={item.id}
                        key={item.id}
                      />
                    ))}
                  </Select>
                )}
                name="reason"
              />
              <FormControl.ErrorMessage>
                {errors.reason?.message}
              </FormControl.ErrorMessage>
            </FormControl>
          </VStack>
          <VStack width="100%" space={4} alignItems="center">
            <FormControl>
              <FormControl.Label>备注: </FormControl.Label>
              <Controller
                control={control}
                rules={{ maxLength: 200 }}
                render={({ field: { onChange, value } }) => (
                  <TextArea
                    w="100%"
                    value={value}
                    onChangeText={text => {
                      if (text.length <= 200) {
                        onChange(text);
                      }
                    }}
                    InputRightElement={
                      <View style={styles.textArea}>
                        <Text color="muted.300">{`${
                          value ? value.length : 0
                        }/200`}</Text>
                      </View>
                    }
                  />
                )}
                name="remark"
              />
            </FormControl>
          </VStack>
        </CommonBox>
        <CommonBox style={{ paddingTop: 0 }} boxProps={{ padding: 0 }}>
          <CommonButton
            onPress={handleSubmit(onSubmit)}
            isDisabled={isDisabled}>
            确认中止
          </CommonButton>
        </CommonBox>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  scrollView: {
    flex: 1,
  },
  formItemLayout: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  itemMT: {
    marginBottom: 10,
  },
  textArea: {
    position: 'absolute',
    right: 10,
    bottom: 0,
  },
});
export default Discontinue;

import React, { useEffect, useState } from 'react';
import { Center, Heading, Spinner } from 'native-base';
import Table from '@/components/Table';
import { getAllMaterial } from '@/services/public';
import { getEqpId } from '@/utils/user';
import CommonBox from '@/components/common/CommonBox';

interface ConsumablesProp {
  consumablesType: string;
  consumablesBarCode: string;
}

interface MaterialProp {
  materialType: string;
  materialBarCode: string;
}

const Consumableslumns = [
  { title: '物料类型', dataIndex: 'consumablesType' },
  { title: '条码', dataIndex: 'consumablesBarCode' },
];

const Materialcolumns = [
  { title: '材料类型', dataIndex: 'materialType' },
  { title: '条码', dataIndex: 'materialBarCode' },
];

const ShowInfoTable: React.FC<{ lotId: string }> = ({ lotId }) => {
  const [table, setTable] = useState<{
    consumables: ConsumablesProp[];
    material: MaterialProp[];
  }>({
    consumables: [],
    material: [],
  });

  const [loading, setLoading] = useState<boolean>(false);

  useEffect(() => {
    const initTable = async () => {
      setLoading(true);
      try {
        const eqpId = await getEqpId();
        const res = await getAllMaterial({
          eqpId: eqpId,
          lotId: lotId,
        });
        const { consumablesInfo, materialInfo } = res.data;
        setTable({
          consumables: consumablesInfo,
          material: materialInfo,
        });
        setLoading(false);
      } catch (error) {
        setLoading(false);
      }
    };
    if (lotId) {
      initTable();
    }
  }, [lotId]);

  if (loading) {
    return (
      <Center bg="white">
        <Spinner color="blue.500" />
      </Center>
    );
  }

  return (
    <>
      <CommonBox style={{ paddingTop: 0 }}>
        <Heading size="md" noOfLines={2} fontSize={16} w={'100%'}>
          耗材信息
        </Heading>
        <Table dataSource={table.consumables} columns={Consumableslumns} />
      </CommonBox>
      <CommonBox style={{ paddingTop: 0 }}>
        <Heading size="md" noOfLines={2} fontSize={16} w={'100%'}>
          材料信息
        </Heading>
        <Table dataSource={table.material} columns={Materialcolumns} />
      </CommonBox>
    </>
  );
};

export default ShowInfoTable;

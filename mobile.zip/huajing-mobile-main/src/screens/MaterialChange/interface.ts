import {
  UseFormClearErrors,
  UseFormGetValues,
  UseFormSetError,
} from 'react-hook-form';

export interface ConsumablesProps {
  innerThread: string;
  bondingHead: string;
  checked: boolean;
  consumablesDetail: Array<{
    // innerThread: string;
    consumablesType: string;
    consumablesBarCode: string;
  }>;
  isUpdate?: boolean;
}

export type ConsumableType = {
  item: ConsumablesProps;
  index: number;
  nextConsumablesFocus: (index: number) => void;
  ref: React.ForwardedRef<unknown>;
};

export interface StageTimeMsg {
  consumablesBarCode: string;
  stageTimes: string;
}

export type rowProps = {
  rowData: {
    innerThread: string;
    consumablesType: string;
    consumablesBarCode: string;
  };
  index: number;
  onData?:Function;
  nextBarCodeFocus: (index: number) => void;
  handleOnClear: () => void;
  setStageTimeMsg: React.Dispatch<React.SetStateAction<StageTimeMsg[]>>;
  isAddSucc: boolean;
  ref: React.ForwardedRef<unknown>;
};

export type RefsProps = {
  index: number;
  focus: () => void;
  values: {
    consumablesType: string;
    innerThread: string;
  };
  getValues: UseFormGetValues<{
    innerThread: string;
    consumablesType: string;
    consumablesBarCode: string;
  }>;
  setError: UseFormSetError<{
    innerThread: string;
    consumablesType: string;
    consumablesBarCode: string;
  }>;
  clearErrors: UseFormClearErrors<{
    innerThread: string;
    consumablesType: string;
    consumablesBarCode: string;
  }>;
};

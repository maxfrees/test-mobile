import { Box, Input } from 'native-base';
import React, {
  useState,
  useRef,
  forwardRef,
  useImperativeHandle,
} from 'react';
import { View, StyleSheet, Text } from 'react-native';
import { useForm, Controller, SubmitHandler } from 'react-hook-form';
import { IColProps } from '@/types/Table';
import { getEqpId } from '@/utils/user';
import { boxCompared } from '@/services/materials';
import { responseType, ToastMessage } from '@/utils/errorMessageMap';
import AffixInput from '@/components/AffixInput';
import useToast from '@/hooks/useToast';
import { useAtomValue } from 'jotai';
import { materialInfoAtom, statusInfoAtom } from '../useMaterialAtom';

interface MaterialBoxProps {
  materialType: string;
  materialBarCode: string;
  [props: string]: any;
}

const columns: IColProps<MaterialBoxProps>[] = [
  { title: '序号', dataIndex: 'index', width: 60 },
  { title: '材料类型', dataIndex: 'materialType', width: 100 },
  { title: '条码', dataIndex: 'materialBarCode' },
];

type RowProps = {
  item: MaterialBoxProps;
  index: number;
  changeWrap: (index: number) => void;
  ref: React.ForwardedRef<unknown>;
};
const Row: React.FC<RowProps> = forwardRef(
  ({ item: { materialBarCode, materialType }, index, changeWrap }, ref) => {
    const { lotId } = useAtomValue(statusInfoAtom);

    const [isCheck, setCheck] = useState<boolean>(false);

    const inputRef = useRef({ focus: () => {} });

    const { setShowToast } = useToast();

    const { handleSubmit, control } = useForm<MaterialBoxProps>({
      defaultValues: {
        materialBarCode,
        materialType,
      },
    });

    useImperativeHandle(ref, () => ({
      focus: () => {
        inputRef.current.focus();
      },
    }));

    const onSubmit: SubmitHandler<MaterialBoxProps> = async data => {
      try {
        const eqpId = await getEqpId();
        const res = await boxCompared({
          lotId: lotId,
          eqpId: eqpId,
          barCode: data.materialBarCode || '',
        });
        setCheck(!isCheck);
        changeWrap(index);
        setShowToast({
          type: 'success',
          message: ToastMessage(res),
        });
      } catch (error) {
        setShowToast({
          type: 'error',
          message: ToastMessage(error as responseType),
        });
      }
    };

    return (
      <View style={styles.table}>
        <View style={{ width: 60!, padding: 10!, justifyContent: 'center'! }}>
          <Text>{index + 1}</Text>
        </View>
        <View style={{ width: 100!, padding: 10!, justifyContent: 'center'! }}>
          <Controller
            control={control}
            render={({ field: { onChange, value } }) => (
              <Input value={value} onChangeText={onChange} isDisabled />
            )}
            name="materialType"
          />
        </View>
        <View style={styles.row}>
          <Controller
            control={control}
            render={({ field: { onChange, value } }) => (
              <AffixInput
                w="100%"
                isDisabled={isCheck}
                isReadOnly={isCheck}
                value={value.toString()}
                inputRef={inputRef}
                onSubmitEditing={handleSubmit(onSubmit)}
                onChangeText={onChange}
                autoCorrect={false}
              />
            )}
            name="materialBarCode"
          />
        </View>
      </View>
    );
  },
);

const MaterialBox = forwardRef<any>(({}, ref) => {
  const materialBoxRefsList = useRef<any[]>([]);

  const { materialBoxInfo } = useAtomValue(materialInfoAtom);

  const changeWrap = (i: number) => {
    if (i + 1 === materialBoxRefsList.current.length) {
      return;
    }
    materialBoxRefsList.current[i + 1].focus();
  };

  useImperativeHandle(ref, () => ({
    materialBoxRefs: materialBoxRefsList,
  }));

  return (
    <Box
      bg="white"
      rounded="lg"
      width="100%"
      marginBottom={6}
      flexDirection="row"
      flexWrap="wrap">
      <View style={styles.tableHeader}>
        {columns.map((col, index) => {
          return (
            <Text
              style={
                col.width ? { width: col.width, padding: 10! } : styles.row
              }
              key={(col.dataIndex as string) + '' + index}>
              {col.title}
            </Text>
          );
        })}
      </View>
      {materialBoxInfo.map((item, index) => {
        return (
          <Row
            ref={el => {
              if (el) {
                materialBoxRefsList.current[index] = el;
              }
            }}
            item={item}
            key={index}
            index={index}
            changeWrap={changeWrap}
          />
        );
      })}
    </Box>
  );
});

const styles = StyleSheet.create({
  table: {
    width: '100%',
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  row: {
    flex: 1,
    paddingHorizontal: 10,
    paddingVertical: 10,
  },
  tableHeader: {
    width: '100%',
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  submitBtn: {
    alignItems: 'flex-start',
    justifyContent: 'center',
  },
});
export default MaterialBox;

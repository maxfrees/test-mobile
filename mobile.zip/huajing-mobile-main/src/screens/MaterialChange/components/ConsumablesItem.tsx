import React, { forwardRef, useImperativeHandle, useRef } from 'react';
import { FormControl, HStack, Input, VStack } from 'native-base';
import { Controller, useForm } from 'react-hook-form';
import AffixInput from '@/components/AffixInput';
import { RefsProps, rowProps } from '../interface';
import { checkAndGetConsumablesInfo } from '@/services/materials';
import { getEqpId } from '@/utils/user';
import { useAtomValue } from 'jotai';
import { statusInfoAtom } from '../useMaterialAtom';
import { ToastMessage, responseType } from '@/utils/errorMessageMap';
import useToast from '@/hooks/useToast';

const ConsumablesItem: React.FC<rowProps> = forwardRef(
  ({ rowData, index, nextBarCodeFocus, isAddSucc, setStageTimeMsg,handleOnClear }, ref) => {
    const barCodeInputRef = useRef({ focus: () => {} });
    const { setShowToast } = useToast();

    const { lotId, stepId } = useAtomValue(statusInfoAtom);

    const {
      handleSubmit,
      control,
      getValues,
      setError,
      clearErrors,
      formState: { errors },
    } = useForm<rowProps['rowData']>({
      defaultValues: {
        innerThread: rowData.innerThread || '',
        consumablesType: rowData.consumablesType,
        consumablesBarCode: rowData.consumablesBarCode,
      },
    });

    const setNextBarCodeFocus = async (data: rowProps['rowData']) => {
      try {
        const eqpId = await getEqpId();
        const res = await checkAndGetConsumablesInfo({
          ...data,
          lotId,
          stepId,
          eqpId,
        });
        setStageTimeMsg(prev => {
          if (prev[index]) {
            prev[index] = {
              consumablesBarCode: data.consumablesBarCode,
              stageTimes: res.data.stageTimes,
            };
          } else {
            prev.push({
              consumablesBarCode: data.consumablesBarCode,
              stageTimes: res.data.stageTimes,
            });
          }
          return prev.slice();
        });
        nextBarCodeFocus(index);
      } catch (error) {
        setShowToast({
          type: 'error',
          message: ToastMessage(error as responseType),
        });
      }
    };
    useImperativeHandle(
      ref,
      (): RefsProps => ({
        index,
        focus: () => {
          barCodeInputRef.current.focus();
        },
        values: {
          consumablesType: rowData.consumablesType,
          innerThread: rowData.innerThread || '',
        },
        getValues: getValues,
        setError,
        clearErrors,
      }),
    );

    return (
      <HStack
        space={3}
        alignItems="baseline"
        justifyContent="space-between"
        mb={2}>
        <VStack width="30%" alignItems="center">
          <FormControl>
            <FormControl.Label>内引线规格: </FormControl.Label>
            <Controller
              control={control}
              render={({ field: { onChange, value } }) => (
                <Input
                  w="100%"
                  value={value}
                  onChangeText={onChange}
                  isDisabled
                  isReadOnly
                />
              )}
              name="innerThread"
            />
          </FormControl>
        </VStack>
        <VStack width="20%" alignItems="center">
          <FormControl>
            <FormControl.Label>物料类型: </FormControl.Label>
            <Controller
              control={control}
              render={({ field: { onChange, value } }) => (
                <Input
                  w="100%"
                  value={value}
                  onChangeText={onChange}
                  isDisabled
                  isReadOnly
                />
              )}
              name="consumablesType"
            />
          </FormControl>
        </VStack>
        <VStack width="40%" alignItems="center">
          <FormControl
            isInvalid={'consumablesBarCode' in errors}>
            <FormControl.Label>条码: </FormControl.Label>
            <Controller
              control={control}
              render={({ field: { onChange, value } }) => (
                <AffixInput
                  w="100%"
                  isDisabled={isAddSucc}
                  isReadOnly={isAddSucc}
                  value={value}
                  autoCapitalize="none"
                  secureTextEntry={true}
                  keyboardType={'visible-password'}
                  inputRef={barCodeInputRef}
                  onSubmitEditing={handleSubmit(setNextBarCodeFocus)}
                  onChangeText={text => {
                    onChange(text.replace(/——/g, '-').toUpperCase());
                    if(!text?.length){
                      handleOnClear()
                    }
                  }}
                />
              )}
              name="consumablesBarCode"
            />
            <FormControl.ErrorMessage>
              {errors.consumablesBarCode?.message}
            </FormControl.ErrorMessage>
          </FormControl>
        </VStack>
      </HStack>
    );
  },
);
export default ConsumablesItem;

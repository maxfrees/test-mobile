import { Box, Input, Switch } from 'native-base';
import React, {
  useRef,
  forwardRef,
  useImperativeHandle,
  useState,
} from 'react';
import { View, StyleSheet, Text } from 'react-native';
import { useForm, Controller, FormProvider } from 'react-hook-form';
import { IColProps } from '@/types/Table';
import AffixInput from '@/components/AffixInput';
import MaterialButton from './MaterialButton';
import { useAtomValue } from 'jotai';
import { materialInfoAtom, statusInfoAtom } from '../useMaterialAtom';

interface MateriaProps {
  materialType: string;
  materialBarCode: string;
  bondingHead: string;
  checked: boolean;
}

type MaterialCardTypes = { onAction: () => void };

const columns: IColProps<MateriaProps>[] = [
  { title: '材料类型', dataIndex: 'materialType', width: 80 },
  { title: '条码', dataIndex: 'materialBarCode' },
  { title: '键合头', dataIndex: 'bondingHead', width: 140 },
  { title: '是否勾选', dataIndex: 'checked', width: 80 },
];

interface RowProps {
  item: MateriaProps;
  stepId: string;
  lotId: string;
  index: number;
  addSucc: boolean;
  onChangeWrap: (index: number) => void;
}

export type RowMethodsTypes = {
  focus: () => void;
  getValues: () => void;
};

const Row = forwardRef<RowMethodsTypes, RowProps>(
  (
    {
      item: { checked, materialType, materialBarCode, bondingHead },
      index,
      addSucc,
      onChangeWrap,
    },
    ref,
  ) => {
    const { isTrackIn } = useAtomValue(statusInfoAtom);

    const materialBarCodeInputRef = useRef({ focus: () => {} });

    const bondingHeadInputRef = useRef({ focus: () => {} });

    const methods = useForm<MateriaProps & { isUpdate?: boolean }>({
      defaultValues: {
        checked,
        materialType,
        materialBarCode,
        bondingHead,
        isUpdate: false,
      },
    });

    const setBondingHeadFocus = () => {
      setTimeout(() => {
        bondingHeadInputRef.current.focus();
      }, 400);
    };

    useImperativeHandle(ref, () => ({
      focus: () => {
        setTimeout(() => {
          materialBarCodeInputRef.current.focus();
        }, 400);
      },
      getValues: methods.getValues,
    }));

    return (
      <FormProvider {...methods}>
        <View style={styles.table}>
          <View style={{ width: 80!, padding: 10! }}>
            <Controller
              control={methods.control}
              render={({ field: { onChange, value } }) => (
                <Input
                  value={value}
                  onChangeText={onChange}
                  isDisabled
                  isReadOnly
                />
              )}
              name="materialType"
            />
          </View>
          <View style={[styles.row, { paddingVertical: 10! }]}>
            <Controller
              control={methods.control}
              render={({ field: { onChange, value } }) => (
                <AffixInput
                  isDisabled={addSucc}
                  isReadOnly={addSucc}
                  value={value.toString()}
                  inputRef={materialBarCodeInputRef}
                  onSubmitEditing={setBondingHeadFocus}
                  onChangeText={onChange}
                />
              )}
              name="materialBarCode"
            />
          </View>
          <View style={{ width: 140!, padding: 10! }}>
            <Controller
              control={methods.control}
              render={({ field: { onChange, value } }) => (
                <AffixInput
                  w="100%"
                  isDisabled={addSucc || isTrackIn}
                  isReadOnly={addSucc || isTrackIn}
                  inputRef={bondingHeadInputRef}
                  value={value.toString()}
                  onSubmitEditing={() => onChangeWrap(index)}
                  onChangeText={onChange}
                />
              )}
              name="bondingHead"
            />
          </View>
          <View style={{ width: 80!, padding: 10! }}>
            <Controller
              control={methods.control}
              render={({ field: { onChange, value } }) => (
                <View style={styles.checkedView}>
                  <Switch
                    onToggle={onChange}
                    isChecked={value ? true : false}
                    onTrackColor="blue.500"
                    isDisabled={addSucc}
                  />
                </View>
              )}
              name="checked"
            />
          </View>
        </View>
      </FormProvider>
    );
  },
);

const MaterialCard = forwardRef<any, MaterialCardTypes>(({ onAction }, ref) => {
  const [addSucc, setAddSucc] = useState(false);

  const { materialInfo } = useAtomValue(materialInfoAtom);

  const { lotId, stepId } = useAtomValue(statusInfoAtom);

  const materialInputRefsList = useRef<RowMethodsTypes[]>([]);

  const onChangeWrap = (index: number) => {
    if (index + 1 === materialInputRefsList.current.length) {
      return;
    }
    materialInputRefsList.current[index + 1].focus();
  };

  useImperativeHandle(ref, () => ({
    materialRowRefs: materialInputRefsList,
  }));

  return (
    <>
      <Box
        bg="white"
        rounded="lg"
        width="100%"
        flexDirection="row"
        flexWrap="wrap">
        <View style={styles.tableHeader}>
          {columns.map((col, index) => {
            return (
              <Text
                style={[
                  col.width ? { width: col.width } : styles.row,
                  styles.shareCell,
                ]}
                key={(col.dataIndex as string) + '' + index}>
                {col.title}
              </Text>
            );
          })}
        </View>
        {materialInfo.map((item, index) => {
          return (
            <Row
              ref={el => {
                if (el) {
                  materialInputRefsList.current[index] = el;
                }
              }}
              onChangeWrap={onChangeWrap}
              item={item}
              lotId={lotId}
              key={index}
              stepId={stepId}
              addSucc={addSucc}
              index={index}
            />
          );
        })}
      </Box>
      <MaterialButton
        materialInputRefsList={materialInputRefsList}
        onAction={onAction}
        setAddSucc={() => setAddSucc(true)}
      />
    </>
  );
});

const styles = StyleSheet.create({
  table: {
    width: '100%',
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  row: {
    flex: 1,
  },
  shareCell: {
    paddingHorizontal: 10,
    paddingVertical: 10,
    justifyContent: 'center',
    textAlignVertical: 'center',
  },
  tableHeader: {
    width: '100%',
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  checkedView: {
    width: '70%',
    alignItems: 'flex-start',
    justifyContent: 'center',
    paddingVertical: 10,
  },
  submitBtn: {
    alignItems: 'flex-start',
    justifyContent: 'center',
  },
  barCodeTitle: {
    width: 140,
    paddingHorizontal: 10,
    paddingVertical: 10,
  },
  barCode: {
    width: 140,
    paddingHorizontal: 10,
    paddingVertical: 10,
  },
});
export default MaterialCard;

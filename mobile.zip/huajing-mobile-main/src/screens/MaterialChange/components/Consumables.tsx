import {
  Box,
  Switch,
  VStack,
  HStack,
  FormControl,
  Text,
  Stack,
} from 'native-base';
import React, {
  useRef,
  forwardRef,
  useImperativeHandle,
  useState,
  useEffect,
} from 'react';
import { useForm, Controller, FormProvider } from 'react-hook-form';
import ConsumablesItem from './ConsumablesItem';
import AffixInput from '@/components/AffixInput';
import { ConsumablesProps, ConsumableType, StageTimeMsg } from '../interface';
import { View } from 'react-native';
import { useAtomValue } from 'jotai';
import { statusInfoAtom } from '../useMaterialAtom';

const INPUTBORDERCOLOR = ['yellow.500', 'primary.500'];

export const bondingHeadReg = /^\d{1}$/;

const Consumables = forwardRef<any, ConsumableType>(
  (
    {
      item: { checked, bondingHead, consumablesDetail, innerThread },
      index,
      nextConsumablesFocus,
    },
    ref,
  ) => {
    const methods = useForm<ConsumablesProps>({
      defaultValues: {
        bondingHead: bondingHead ? bondingHead : '',
        checked: checked ? true : false,
        isUpdate: false,
      },
    });

    const [stageTimeMsg, setStageTimeMsg] = useState<StageTimeMsg[]>([]);


    const { isTrackIn } = useAtomValue(statusInfoAtom);

    const [isSucc, setAddSucc] = useState(false);

    const consumablesRows = useRef<any[]>([]);

    const bondingHeadInputRef = useRef({ focus: () => {} });

    const setFirstBarCodeFocus = () => {
      if (consumablesDetail?.length >= 1) {
        setTimeout(() => {
          consumablesRows.current[0].focus();
        }, 400);
      }
    };

    useEffect(()=>{
      console.log('执行');
      const arr = consumablesDetail?.map((item)=>({
            consumablesBarCode: '',
        stageTimes: ''
      }));
      setStageTimeMsg([...arr])
    },[])

   
    const handleOnClear = (i:number)=>{
      const temp = [...stageTimeMsg];
      console.log(temp,i)
      temp[i] = {
        consumablesBarCode: '',
        stageTimes: ''
      }
      console.log(temp,i)
      setStageTimeMsg(temp)
    }

    const nextBarCodeFocus = (i: number) => {
      if (i + 1 === consumablesRows?.current.length) {
        setTimeout(() => {
          // 这里的index是键合头数量
          nextConsumablesFocus(index);
        }, 400);
      } else {
        setTimeout(() => {
          consumablesRows.current[i + 1].focus();
        }, 400);
      }
    };

    useImperativeHandle(ref, () => ({
      focus: () => {
        bondingHeadInputRef.current.focus();
      },
      bondingHead: methods.getValues, 
      checked: methods.getValues,
      consumablesList: consumablesRows.current,
      stageTimeMsg,
      ...methods,
      setAddSucc: () => setAddSucc(true),
    }));

    return (
      <FormProvider {...methods}>
        <Box
          bg="white"
          rounded="lg"
          width="100%"
          p={2}
          mt={2}
          flexDirection="column"
          flexWrap="wrap">
          <HStack
            space={3}
            alignItems="center"
            justifyContent="flex-start"
            mb={2}>
            <VStack width="40%" alignItems="center">
              <FormControl
                isRequired
                isInvalid={'bondingHead' in methods.formState.errors}>
                <Controller
                  control={methods.control}
                  rules={{
                    validate: value => {
                      if (value) {
                        if (bondingHeadReg.test(value)) {
                          return true;
                        } else {
                          return '键合头不正确';
                        }
                      } else {
                        return '请输入键合头';
                      }
                    },
                  }}
                  render={({ field: { onChange, value } }) => (
                    <Stack alignItems="center" flexDir="row">
                      <Text w="30%">
                        键合头:
                        <Text color="red.500">*</Text>
                      </Text>
                      <AffixInput
                        w="60%"
                        borderColor={INPUTBORDERCOLOR[index] || 'blue.300'}
                        isDisabled={isSucc || isTrackIn}
                        isReadOnly={isSucc || isTrackIn}
                        inputRef={bondingHeadInputRef}
                        onSubmitEditing={methods.handleSubmit(
                          setFirstBarCodeFocus,
                        )}
                        value={value.toString()}
                        onChangeText={onChange}
                      />
                    </Stack>
                  )}
                  name="bondingHead"
                />
                <FormControl.ErrorMessage>
                  {methods.formState.errors.bondingHead?.message}
                </FormControl.ErrorMessage>
              </FormControl>
            </VStack>
            <VStack width="40%" alignItems="center">
              <FormControl>
                <Controller
                  control={methods.control}
                  render={({ field: { onChange, value } }) => (
                    <Stack alignItems="center" flexDir="row">
                      <Text w="40%">是否勾选: </Text>
                      <HStack justifyContent="flex-start" py={2} w="50%">
                        <Switch
                          onToggle={onChange}
                          isChecked={value ? true : false}
                          isDisabled={isSucc}
                        />
                      </HStack>
                    </Stack>
                  )}
                  name="checked"
                />
              </FormControl>
            </VStack>
          </HStack>
          {consumablesDetail?.map((item, i) => {
            return (
              <ConsumablesItem
                key={i}
                index={i}
                ref={el => {
                  if (el) {
                    consumablesRows.current[i] = el;
                  }
                }}
                nextBarCodeFocus={nextBarCodeFocus}
                setStageTimeMsg={setStageTimeMsg}
                handleOnClear={()=>handleOnClear(i)}
                isAddSucc={isSucc}
                rowData={Object.assign({}, item, { innerThread: innerThread })}
              />
            );
          })}
          <View
            style={{
              width: '100%',
              flexDirection: 'row',
              flexWrap: 'wrap',
            }}>
            {stageTimeMsg.map((stage, i) => {
              return (
               stage.consumablesBarCode ? <Text
                  key={stage.consumablesBarCode + i + ''}
                  style={{
                    width: '50%',
                    padding: 10,
                  }}>
                  {stage.consumablesBarCode}: {stage.stageTimes + ''} 
                </Text>:<Text></Text>
              );
            })}
          </View>
        </Box>
      </FormProvider>
    );
  },
);
export default Consumables;

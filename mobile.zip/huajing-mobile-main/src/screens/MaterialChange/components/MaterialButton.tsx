import React, { useState } from 'react';
import { View, StyleSheet } from 'react-native';
import LoadingButton from '@/components/LoadingButton';
import { materialCompared, materialComparedTypes } from '@/services/materials';
import { responseType, ToastMessage } from '@/utils/errorMessageMap';
import { getEqpId } from '@/utils/user';
import useToast from '@/hooks/useToast';
import { useAtomValue } from 'jotai';
import { statusInfoAtom } from '../useMaterialAtom';

type Props = {
  materialInputRefsList: React.MutableRefObject<any[]>;
  onAction: () => void;
  setAddSucc: () => void;
};

const MaterialButton: React.FC<Props> = ({
  materialInputRefsList,
  onAction,
  setAddSucc,
}) => {
  const [disabled, setDisabled] = useState(false);

  const { lotId } = useAtomValue(statusInfoAtom);

  const { setShowToast } = useToast();

  const onSubmit = async () => {
    try {
      const eqpId = await getEqpId();
      const values = materialInputRefsList.current.map(c => {
        const v = c.getValues();
        return {
          bondingHead: v.bondingHead,
          materialType: v.materialType,
          materialBarCode: v.materialBarCode,
          Checked: v.checked ? 1 : 0,
        };
      }) as materialComparedTypes['materail'];

      const res = await materialCompared({
        eqpId: eqpId,
        lotId: lotId,
        materail: values,
      });

      setAddSucc();
      setDisabled(true);

      onAction();

      setShowToast({
        type: 'success',
        message: ToastMessage(res),
      });
    } catch (error) {
      setShowToast({
        type: 'error',
        message: ToastMessage(error as responseType),
      });
      setDisabled(false);
    }
  };

  return (
    <View style={styles.btn}>
      <LoadingButton
        title={'确认新增'}
        onPress={onSubmit}
        size="sm"
        colorScheme={'blue'}
        width={100}
        mt={2}
        isDisabled={disabled}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  btn: {
    width: '100%',
    alignItems: 'flex-end',
  },
});

export default MaterialButton;

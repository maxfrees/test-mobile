import React, { useRef, forwardRef, useImperativeHandle } from 'react';
import { Box, Heading } from 'native-base';
import MaterialCard from './MaterialCard';
import { useAtomValue } from 'jotai';
import { materialInfoAtom } from '../useMaterialAtom';

interface IComponentProps {
  focusMaterialBox: () => void;
}

const MaterialInfoComponent = forwardRef<any, IComponentProps>(
  ({ focusMaterialBox }, ref) => {
    const { materialInfo } = useAtomValue(materialInfoAtom);

    const materialRowRefs = useRef<any>();

    useImperativeHandle(ref, () => ({
      rows: materialRowRefs,
    }));

    if (!materialInfo.length) {
      return null;
    }

    return (
      <Box rounded="lg" width="100%" p={2} flexDirection="row" flexWrap="wrap">
        <Heading
          size="md"
          noOfLines={2}
          fontSize={16}
          w={'100%'}
          paddingBottom={4}>
          材料信息
        </Heading>
        <MaterialCard ref={materialRowRefs} onAction={focusMaterialBox} />
      </Box>
    );
  },
);

export default MaterialInfoComponent;

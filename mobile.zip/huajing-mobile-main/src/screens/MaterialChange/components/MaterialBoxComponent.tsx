import { Box, Heading } from 'native-base';
import React, { forwardRef, useImperativeHandle, useRef } from 'react';
import MaterialBox from './materialBox';
import { useAtomValue } from 'jotai';
import { materialInfoAtom, statusInfoAtom } from '../useMaterialAtom';

const MaterialBoxComponent = forwardRef((props, ref) => {
  const { isTrackIn } = useAtomValue(statusInfoAtom);

  const { materialBoxInfo } = useAtomValue(materialInfoAtom);

  const materialBoxRefs = useRef<any>();

  useImperativeHandle(ref, () => ({
    boxs: materialBoxRefs,
  }));

  if (isTrackIn) {
    return null;
  }

  if (!materialBoxInfo.length) {
    return null;
  }

  return (
    <Box rounded="lg" width="100%" p={2} flexDirection="row" flexWrap="wrap">
      <Heading
        size="md"
        noOfLines={2}
        fontSize={16}
        w={'100%'}
        paddingBottom={4}>
        料盒信息
      </Heading>
      <MaterialBox ref={materialBoxRefs} />
    </Box>
  );
});

export default MaterialBoxComponent;

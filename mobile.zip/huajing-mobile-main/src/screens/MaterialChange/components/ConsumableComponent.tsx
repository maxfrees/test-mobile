import React, { useCallback, useRef, useState } from 'react';
import { Box, Heading } from 'native-base';
import ConsumableButton from './ConsumableButton';
import Consumables from './Consumables';
import { useAtomValue } from 'jotai';
import { materialInfoAtom } from '../useMaterialAtom';
import { View } from 'react-native';

interface ConsumablesProps {
  innerThread: string;
  bondingHead: string;
  checked: boolean;
  consumablesDetail: Array<{
    // innerThread: string;
    consumablesType: string;
    consumablesBarCode: string;
  }>;
  isUpdate?: boolean;
}

const ConsumableComponent: React.FC<{ focusMaterialInfo: () => void }> = ({
  focusMaterialInfo,
}) => {
  const { consumablesInfo } = useAtomValue(materialInfoAtom);
  const consumablesInputRefsList = useRef<any[]>([]);
  const [stageMsgList,setStageMsgList] = useState<any[]>([]);
  let test:any = []

  const autoFocusInput = () => {
    setTimeout(() => {
      if (consumablesInputRefsList.current.length) {
        consumablesInputRefsList.current[0].focus();
      }
    }, 400);
  };

  const nextConsumablesFocus = useCallback((index: number) => { 
    if (index + 1 === consumablesInputRefsList.current.length) {
      return;
    }
    consumablesInputRefsList.current[index + 1].focus();
  }, []);

  if (!consumablesInfo.length) {
    return null;
  }
  
  autoFocusInput();

  return (
    <Box rounded="lg" width="100%" p={2} flexDirection="row" flexWrap="wrap">
      <Heading size="md" noOfLines={2} fontSize={16} w={'100%'}>
        耗材信息
      </Heading>
      {consumablesInfo?.map((item, index) => (
        
        <Consumables
          ref={el => {
            if (el) {
              consumablesInputRefsList.current[index] = el;
              test[index] = el.stageTimeMsg[0];
            }
          }}
          nextConsumablesFocus={nextConsumablesFocus}
          index={index}
          item={item}
          key={index}
        />
      ))}
      <View 
        style={{
          flexDirection: 'row',
          justifyContent: 'space-between',
          marginTop: 10,
        }}>
        <ConsumableButton
          consumablesInputRefsList={consumablesInputRefsList}
          stageMsgList={test}
          onAction={focusMaterialInfo}
        />
      </View>
    </Box>
  );
};

export default ConsumableComponent;

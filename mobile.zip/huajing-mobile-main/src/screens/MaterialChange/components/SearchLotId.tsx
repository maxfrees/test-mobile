import React, { useContext, useEffect, useState } from 'react';
import { CommonActions, useNavigation } from '@react-navigation/native';
import {
  NativeSyntheticEvent,
  Pressable,
  StyleSheet,
  Text,
  TextInputSubmitEditingEventData,
  View,
} from 'react-native';
import AffixInput from '@/components/AffixInput';
import { useAtom, useSetAtom } from 'jotai';
import { materialInfoAtom, statusInfoAtom } from '../useMaterialAtom';
import { getEqpId } from '@/utils/user';
import { getLotInfo } from '@/services/public';
import { getMaterials } from '@/services/materials';
import { ToastMessage, responseType } from '@/utils/errorMessageMap';
import useToast from '@/hooks/useToast';
import { ActionLoadingContext } from '@/context/LoadingContext';

const SearchLotId: React.FC = () => {
  const navigation = useNavigation();

  const [statusInfo, setMaterialStatus] = useAtom(statusInfoAtom);

  const setMaterialInfo = useSetAtom(materialInfoAtom);

  const [lotIdValue, setLotIdValue] = useState<string>('');

  const dispatch = useContext(ActionLoadingContext);

  const { setShowToast } = useToast();

  const handleSetLotId = async ({
    nativeEvent: { text },
  }: NativeSyntheticEvent<TextInputSubmitEditingEventData>) => {
    dispatch({ type: 'SHOW' });
    try {
      const eqpId = await getEqpId();
      const res = await getMaterials({
        eqpId: eqpId,
        lotId: text,
      });
      setMaterialInfo({
        consumablesInfo: res.data.consumablesInfocount || [],
        materialInfo: res.data.materialInfo || [],
        materialBoxInfo: res.data.materialBoxInfo || [],
      });
      setMaterialStatus(prev => ({ ...prev, lotId: text }));
    } catch (error) {
      setShowToast({
        type: 'error',
        message: ToastMessage(error as responseType),
      });
    } finally {
      dispatch({ type: 'HIDE' });
    }
  };

  useEffect(() => {
    (async () => {
      dispatch({ type: 'SHOW' });
      try {
        const eqpId = await getEqpId();
        //获取下最新的开批状态
        const lotInfo = await getLotInfo({ eqpId: eqpId });
        if (lotInfo.data.trackStatus) {
          const materialInfo = await getMaterials({
            eqpId: eqpId,
            lotId: lotInfo.data.lotId as string,
          });
          const res = materialInfo.data;

          setMaterialStatus(prev => ({
            ...prev,
            stepId: res.data.stepId,
            isTrackIn: !!res.data.trackStatus,
            lotId: res.data.lotId,
          }));

          setMaterialInfo({
            consumablesInfo: res.data.consumablesInfocount || [],
            materialInfo: res.data.materialInfo || [],
            materialBoxInfo: res.data.materialBoxInfo || [],
          });

          setLotIdValue(res.data.lotId);
        }
      } catch (error) {
        setShowToast({
          type: 'error',
          message: ToastMessage(error as responseType),
        });
      } finally {
        dispatch({ type: 'HIDE' });
      }
    })();
  }, [dispatch, setMaterialInfo, setMaterialStatus, setShowToast]);

  return (
    <View style={styles.cardHead}>
      <View style={styles.materialsTitle}>
        <Text>作业批号: </Text>
        <AffixInput
          w={280}
          autoCapitalize="none"
          secureTextEntry={true}
          keyboardType={'visible-password'}
          isDisabled={statusInfo.isTrackIn}
          isReadOnly={statusInfo.isTrackIn}
          onSubmitEditing={handleSetLotId}
          value={lotIdValue}
          onChangeText={text => {
            setLotIdValue(text.replace(/——/g, '-').toUpperCase());
          }}
          autoFocus={!lotIdValue}
        />
      </View>
      <Pressable
        onPress={() =>
          navigation.dispatch(
            CommonActions.navigate({
              name: 'MaterialsHistory',
              params: {
                lotId: statusInfo.lotId,
              },
            }),
          )
        }>
        <Text style={{ color: '#3b82f6' }}>查看物料历史记录</Text>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  cardHead: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  materialsTitle: {
    flexDirection: 'row',
    alignItems: 'center',
  },
});

export default SearchLotId;

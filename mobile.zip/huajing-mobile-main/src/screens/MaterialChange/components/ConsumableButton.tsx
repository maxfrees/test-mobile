import React, { useState } from 'react';
import { getEqpId } from '@/utils/user';
import {
  consumablesCompared,
  consumablesComparedTypes,
} from '@/services/materials';
import {
  errMessageMap,
  responseType,
  ToastMessage,
} from '@/utils/errorMessageMap';
import { RefsProps } from '../interface';
import LoadingButton from '@/components/LoadingButton';
import { bondingHeadReg } from './Consumables';
import useToast from '@/hooks/useToast';
import { View } from 'react-native';
import { useAtomValue } from 'jotai';
import { statusInfoAtom } from '../useMaterialAtom';

type Props = {
  consumablesInputRefsList: React.MutableRefObject<any[]>;
  stageMsgList:any;
  onAction: () => void;
};

const ConsumableButton: React.FC<Props> = ({
  consumablesInputRefsList,
  stageMsgList,
  onAction,
}) => {
  const [disabled, setDisabled] = useState(false);

  const { lotId, isTrackIn } = useAtomValue(statusInfoAtom);

  const { setShowToast } = useToast();

  const onSubmit = async () => {
    resetValid();

    if (validEmpty()) {
      try {
        const eqpId = await getEqpId();
        const consumablesDetail = consumablesInputRefsList.current.map(row => {
  
          return {
            consumablesDetail: row.consumablesList.map((ele: RefsProps) => ({
              ...ele.values,
              consumablesBarCode: ele.getValues('consumablesBarCode'),
              bondingHead: row.bondingHead('bondingHead'),
              Checked: row.bondingHead('checked') ? 1 : 0,
            })),
          };
        });
        const res = await consumablesCompared({
          eqpId,
          lotId: lotId,
          consumablesInfocount: consumablesDetail.reduce((total, current) => {
            return total.concat(current.consumablesDetail);
          }, []) as consumablesComparedTypes['consumablesInfocount'],
        });

        consumablesInputRefsList.current.forEach(c => {
          c.setAddSucc();
        });

        setDisabled(true);

        onAction();

        setShowToast({
          type: 'success',
          message: ToastMessage(res),
        });
      } catch (error: any) {
        const errorData = error.data;

        const getAllBondingHeadErrorFn = consumablesInputRefsList.current.map(
          f => f.setError,
        );

        const getAllBarCodeErrorFn = consumablesInputRefsList.current.reduce(
          (total, current) => {
            const child = current.consumablesList.map(
              (c: RefsProps) => c.setError,
            );
            return total.concat(child);
          },
          [],
        );
        //获取所有键合头
        const getAllBondingHead: String[] =
          consumablesInputRefsList.current.map(c =>
            c.bondingHead('bondingHead'),
          );

        // 获取所有条码
        const getAllBarCode: String[] = consumablesInputRefsList.current.reduce(
          (total, current) => {
            const child = current.consumablesList.map((c: RefsProps) =>
              c.getValues('consumablesBarCode'),
            );
            return total.concat(child);
          },
          [],
        );

        let count = 0;

        getAllBondingHead.forEach((code, index) => {
          if (code === errorData[0]) {
            count++;
            getAllBondingHeadErrorFn[index]('bondingHead', {
              type: 'manual',
              message: errMessageMap[error.message] + errorData[0],
            });
          }
        });

        getAllBarCode.forEach((code, index) => {
          if (code === errorData[0]) {
            count++;
            getAllBarCodeErrorFn[index]('consumablesBarCode', {
              type: 'manual',
              message: errMessageMap[error.message] + errorData[0],
            });
          }
        });
        // 害😅
        if (!count) {
          setShowToast({
            type: 'success',
            message: ToastMessage(error as responseType),
          });
        }
      }
    }
  };

  const resetValid = () => {
    consumablesInputRefsList.current.forEach(current => {
      current.clearErrors('bondingHead');
      current.consumablesList.forEach((c: RefsProps) => {
        c.clearErrors('consumablesBarCode');
      });
    });
  };

  const validEmpty: () => boolean = () => {
    let count = 0;
    let isEmptyOk = false;
    let isStageOk = true;
    consumablesInputRefsList.current.forEach(current => {
      if (current.bondingHead('bondingHead')) {
        if (!bondingHeadReg.test(current.bondingHead('bondingHead'))) {
          count++;
          current.setError('bondingHead', {
            type: 'manual',
            message: '键合头不正确',
          });
        }
      } else {
        count++;
        current.setError('bondingHead', {
          type: 'manual',
          message: '请输入键合头',
        });
      }
      current.consumablesList.forEach((c: RefsProps) => {
        if (!c.getValues('consumablesBarCode') && !isTrackIn) {
          // count++;
          // c.setError('consumablesBarCode', {
          //   type: 'manual',
          //   message: '请输入条码',
          // });
        }else{
          isEmptyOk = true
        }
      });
    });
    if(!isEmptyOk){
      setShowToast({
        type: 'error',
        message: ToastMessage('请至少输入一个条码'),
      });
    }
    console.log(stageMsgList,'list');
    for (let i = 0; i < stageMsgList.length; i++) {
      const item = stageMsgList[i];
      if(item.stageTimes == 'undefined' || item.stageTimes == 'null' ||item.stageTimes == undefined || item.stageTimes == null ){
        isStageOk = false
      }
    }
    if(!isStageOk){
      setShowToast({
        type: 'error',
        message: ToastMessage('值不能为 undefined 或 null'),
      });
    }
    return (count || !isEmptyOk || !isStageOk) ? false : true;
  };

  return (
    <View style={{ width: '100%', alignItems: 'flex-end' }}>
      <LoadingButton
        title={'确认新增'}
        onPress={onSubmit}
        size="sm"
        colorScheme={'blue'}
        width={100}
        isDisabled={disabled}
      />
    </View>
  );
};

export default ConsumableButton;

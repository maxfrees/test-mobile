import React, { useRef, useCallback } from 'react';
import { ScrollView, StyleSheet } from 'react-native';
import { Text } from 'native-base';
import MaterialBoxComponent from './components/MaterialBoxComponent';
import ConsumableComponent from './components/ConsumableComponent';
import MaterialInfoComponent from './components/MaterialInfoComponent';
import SearchLotId from './components/SearchLotId';
import useUnmount from '@/hooks/useUnmount';
import { useResetAtom } from 'jotai/utils';
import { materialInfoAtom, statusInfoAtom } from './useMaterialAtom';
import CommonBox from '@/components/common/CommonBox';

const MaterialChange: React.FC = () => {
  const materialInfoRefs = useRef<any>();

  const materialBoxRefs = useRef<any>();

  const resetStatusInfo = useResetAtom(statusInfoAtom);

  const resetMaterialInfo = useResetAtom(materialInfoAtom);

  const focusMaterialInfo = useCallback(() => {
    // 嵌套的有点深哈=-=
    if (materialInfoRefs.current.rows.current.materialRowRefs.current.length) {
      materialInfoRefs.current.rows.current.materialRowRefs.current[0].focus();
    }
  }, []);

  const focusMaterialBox = useCallback(() => {
    if (materialBoxRefs.current.boxs.current.materialBoxRefs.current.length) {
      materialBoxRefs.current.boxs.current.materialBoxRefs.current[0].focus();
    }
  }, []);

  useUnmount(() => {
    resetStatusInfo();
    resetMaterialInfo();
  });

  return (
    <ScrollView style={styles.scrollView} keyboardShouldPersistTaps="handled">
      {/* 搜索作业批号 */}
      <CommonBox>
        <SearchLotId />
      </CommonBox>
      {/* 耗材信息 */}
      <React.Suspense fallback={() => <Text>loading...</Text>}>
        <ConsumableComponent focusMaterialInfo={focusMaterialInfo} />
      </React.Suspense>
      {/* 材料信息 */}
      <React.Suspense fallback={() => <Text>loading...</Text>}>
        <MaterialInfoComponent
          ref={materialInfoRefs}
          focusMaterialBox={focusMaterialBox}
        />
      </React.Suspense>
      {/* 料盒信息 */}
      <React.Suspense fallback={() => <Text>loading...</Text>}>
        <MaterialBoxComponent ref={materialBoxRefs} />
      </React.Suspense>
    </ScrollView>
  );
};
const styles = StyleSheet.create({
  scrollView: {
    flex: 1,
  },
  card: {
    flex: 1,
    alignItems: 'center',
    paddingTop: 10,
  },
});
export default MaterialChange;

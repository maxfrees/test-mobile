import { Text } from 'native-base';
import React, {
  useEffect,
  useState,
  createContext,
  useRef,
  useCallback,
} from 'react';
import { Pressable, ScrollView, StyleSheet, View } from 'react-native';
import { useNavigation, CommonActions } from '@react-navigation/native';
import { getMaterials } from '@/services/materials';
import { getEqpId } from '@/utils/user';
import { getLotInfo } from '@/services/public';
import AffixInput from '@/components/AffixInput';
import { responseType, ToastMessage } from '@/utils/errorMessageMap';
import MaterialBoxComponent from './components/MaterialBoxComponent';
import ConsumableComponent from './components/ConsumableComponent';
import MaterialInfoComponent from './components/MaterialInfoComponent';
import useToast from '@/hooks/useToast';

type ContextProps = {
  lotId: string;
  stepId: string;
  trackStatus: boolean;
};

type publicState = {
  stepId: string;
  lotId: string;
  isTrackIn: boolean;
};

export const MaterialContext = createContext<ContextProps>({
  lotId: '',
  stepId: '',
  trackStatus: false,
});

const MaterialChange: React.FC = () => {
  const navigation = useNavigation();

  const [lotIdValue, setLotIdValue] = useState('');
  const [publicValues, setPublicValues] = useState<publicState>({
    stepId: '',
    lotId: '',
    isTrackIn: false,
  });

  const materialInfoRefs = useRef<any>();
  const materialBoxRefs = useRef<any>();

  const { setShowToast } = useToast();

  const handleSetLotId = () => {
    setPublicValues(preState => ({ ...preState, lotId: lotIdValue }));
  };

  useEffect(() => {
    (async () => {
      try {
        const eqpId = await getEqpId();
        //获取下最新的开批状态
        const res = await getLotInfo({ eqpId: eqpId });
        if (res.data.trackStatus) {
          const materialInfo = await getMaterials({
            eqpId: eqpId,
            lotId: res.data.lotId as string,
          });
          const { stepId, trackStatus } = materialInfo.data;
          setPublicValues(preState => ({
            ...preState,
            stepId,
            isTrackIn: trackStatus,
            lotId: res.data.lotId as string,
          }));
          setLotIdValue(res.data.lotId as string);
        }
      } catch (error) {
        setShowToast({
          type: 'error',
          message: ToastMessage(error as responseType),
        });
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const focusMaterialInfo = useCallback(() => {
    // 嵌套的有点深哈=-=
    if (materialInfoRefs.current.rows.current.materialRowRefs.current.length) {
      materialInfoRefs.current.rows.current.materialRowRefs.current[0].focus();
    }
  }, []);

  const focusMaterialBox = useCallback(() => {
    if (materialBoxRefs.current.boxs.current.materialBoxRefs.current.length) {
      materialBoxRefs.current.boxs.current.materialBoxRefs.current[0].focus();
    }
  }, []);

  return (
    <ScrollView style={styles.scrollView} keyboardShouldPersistTaps="handled">
      <MaterialContext.Provider
        value={{
          lotId: publicValues.lotId,
          trackStatus: publicValues.isTrackIn,
          stepId: publicValues.stepId,
        }}>
        <View style={styles.card}>
          <View style={styles.cardHead}>
            <View style={styles.materialsTitle}>
              <Text>作业批号: </Text>
              <AffixInput
                w={280}
                autoCapitalize="none"
                secureTextEntry={true}
                keyboardType={'visible-password'}
                isDisabled={publicValues.isTrackIn}
                isReadOnly={publicValues.isTrackIn}
                onSubmitEditing={handleSetLotId}
                value={lotIdValue}
                onChangeText={text => {
                  setLotIdValue(text.replace(/——/g, '-').toUpperCase());
                }}
                autoFocus={!lotIdValue}
              />
            </View>
            <Pressable
              onPress={() =>
                navigation.dispatch(
                  CommonActions.navigate({
                    name: 'MaterialsHistory',
                    params: {
                      lotId: publicValues.lotId,
                    },
                  }),
                )
              }>
              <Text style={styles.historyTitle}>查看物料历史记录</Text>
            </Pressable>
          </View>
          <View>
            {/* 耗材信息 */}
            <React.Suspense fallback={() => <Text>loading...</Text>}>
              <ConsumableComponent focusMaterialInfo={focusMaterialInfo} />
            </React.Suspense>
            <React.Suspense fallback={() => <Text>loading...</Text>}>
              <MaterialInfoComponent
                ref={materialInfoRefs}
                focusMaterialBox={focusMaterialBox}
              />
            </React.Suspense>
            <React.Suspense fallback={() => <Text>loading...</Text>}>
              {!publicValues.isTrackIn && (
                <MaterialBoxComponent ref={materialBoxRefs} />
              )}
            </React.Suspense>
          </View>
        </View>
      </MaterialContext.Provider>
    </ScrollView>
  );
};
const styles = StyleSheet.create({
  scrollView: {
    flex: 1,
  },
  card: {
    flex: 1,
    alignItems: 'center',
    paddingTop: 10,
  },
  cardHead: {
    width: '100%',
    flexDirection: 'row',
    padding: 20,
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  materialsTitle: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  historyTitle: {
    color: '#3b82f6',
  },
});
export default MaterialChange;

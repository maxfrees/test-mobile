import { atomWithReset } from 'jotai/utils';

type MaterialStatusAtom = {
  stepId: string;
  lotId: string;
  isTrackIn: boolean;
};

export const statusInfoAtom = atomWithReset<MaterialStatusAtom>({
  lotId: '',
  stepId: '',
  isTrackIn: false,
});

export const materialInfoAtom = atomWithReset({
  consumablesInfo: [],
  materialInfo: [],
  materialBoxInfo: [],
});

import React, { useReducer, createContext } from 'react';
import RMS_Login from './RMS_Login';
import UploadRecipe from './UploadRecipe';
import { RMS_LoginProps } from './components/InputLogin';

interface AuthRecipeType extends RMS_LoginProps {
  checkLogin: boolean;
}

const defaultValue: AuthRecipeType = {
  userID: '',
  password: '',
  checkLogin: false,
};

interface AuthUploadRecipeAction {
  type: 'SIGN_SUCC';
  payload: AuthRecipeType;
}

interface AuthRecipeContextType extends AuthRecipeType {
  dispatch: React.Dispatch<AuthUploadRecipeAction>;
}

function reducer(
  state = defaultValue,
  action: AuthUploadRecipeAction,
): AuthRecipeType {
  if (action.type === 'SIGN_SUCC') {
    return {
      ...state,
      ...action.payload,
    };
  }

  return state;
}

export const AuthUploadRecipeContext = createContext<AuthRecipeContextType>({
  userID: '',
  password: '',
  checkLogin: false,
  dispatch: () => {},
});

const AuthUploadRecipeProvider: React.FC = () => {
  const [state, dispatch] = useReducer(reducer, defaultValue);
  return (
    <AuthUploadRecipeContext.Provider value={{ ...state, dispatch }}>
      {state.checkLogin ? <UploadRecipe /> : <RMS_Login />}
    </AuthUploadRecipeContext.Provider>
  );
};

export default AuthUploadRecipeProvider;

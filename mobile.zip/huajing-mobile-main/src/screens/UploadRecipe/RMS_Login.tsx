import React, { useContext } from 'react';
import { useNavigation } from '@react-navigation/native';
import { Modal } from 'native-base';
import { AuthUploadRecipeContext } from './RecipeProvider';
import RecipeLogin from './components/RecipeLogin';

const RMS_Login: React.FC = () => {
  const { checkLogin } = useContext(AuthUploadRecipeContext);

  const navigation = useNavigation();

  return (
    <Modal isOpen={!checkLogin} animationPreset="slide">
      <Modal.Content w={'80%'}>
        <Modal.CloseButton
          onPress={() => {
            navigation.goBack();
          }}
        />
        <Modal.Body>
          <RecipeLogin />
        </Modal.Body>
      </Modal.Content>
    </Modal>
  );
};

export default RMS_Login;

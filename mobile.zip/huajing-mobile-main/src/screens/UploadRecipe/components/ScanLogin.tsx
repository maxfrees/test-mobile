import React, { useContext, useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Keyboard,
  NativeSyntheticEvent,
  TextInputSubmitEditingEventData,
  ToastAndroid,
} from 'react-native';
import { Input } from 'native-base';
import CommonBox from '@/components/common/CommonBox';
import useRefInput from '@/hooks/useRefInput';
import { ToastMessage, responseType } from '@/utils/errorMessageMap';
import { colorPrimary } from '@/theme/theme';
import { LoginFormData } from '@/modules/Login/components/InputLogin';
import { authenticateUser } from '@/services/uploadRecipe';
import { AuthUploadRecipeContext } from '../RecipeProvider';

const ScanLogin: React.FC<{ tabIndex: number }> = ({ tabIndex }) => {
  const [loading, setLoading] = useState(false);

  const { dispatch } = useContext(AuthUploadRecipeContext);

  const { delayFocus: scanCodeFocus, component: ScanCodeComponent } =
    useRefInput(Input);

  const onOK = async ({
    nativeEvent: { text },
  }: NativeSyntheticEvent<TextInputSubmitEditingEventData>) => {
    Keyboard.dismiss();

    setLoading(true);
    try {
      const userInfo: LoginFormData = JSON.parse(text);

      const res = await authenticateUser({
        userID: userInfo.username,
        password: userInfo.password,
      });

      dispatch({
        type: 'SIGN_SUCC',
        payload: {
          userID: userInfo.username,
          password: userInfo.password,
          checkLogin: true,
        },
      });
      ToastAndroid.show(ToastMessage(res), ToastAndroid.LONG);
    } catch (error) {
      ToastAndroid.show(ToastMessage(error as responseType), ToastAndroid.LONG);
      setLoading(false);
    }
  };

  useEffect(() => {
    if (tabIndex === 0) {
      scanCodeFocus();
    }
  }, [scanCodeFocus, tabIndex]);

  return (
    <CommonBox style={{ backgroundColor: undefined }} boxProps={{ padding: 0 }}>
      {loading ? (
        <CommonBox>
          <ActivityIndicator color={colorPrimary} />
        </CommonBox>
      ) : (
        <ScanCodeComponent
          placeholder="对准条码, 按扫描枪上扫描键进行登录"
          onSubmitEditing={onOK}
        />
      )}
    </CommonBox>
  );
};

export default ScanLogin;

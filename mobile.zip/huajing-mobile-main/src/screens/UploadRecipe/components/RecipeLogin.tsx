import React, { useState } from 'react';
import { TabScreen, Tabs } from '@/components/Tabs';
import ScanLogin from './ScanLogin';
import InputLogin from './InputLogin';

const RecipeLogin = () => {
  const [tabIndex, changeTabIndex] = useState(0);

  return (
    <Tabs defaultIndex={tabIndex} onChangeIndex={changeTabIndex}>
      <TabScreen label="扫码登录">
        <ScanLogin tabIndex={tabIndex} />
      </TabScreen>
      <TabScreen label="账户密码登录">
        <InputLogin />
      </TabScreen>
    </Tabs>
  );
};

export default RecipeLogin;

import React, { useContext } from 'react';
import { ToastAndroid } from 'react-native';
import { useForm, Controller } from 'react-hook-form';
import { FormControl, Input } from 'native-base';
import CommonBox from '@/components/common/CommonBox';
import useRefInput from '@/hooks/useRefInput';
import CommonButton from '@/components/common/CommonButton';
import { ToastMessage, responseType } from '@/utils/errorMessageMap';
import { authenticateUser } from '@/services/uploadRecipe';
import { AuthUploadRecipeContext } from '../RecipeProvider';

export interface RMS_LoginProps {
  userID: string;
  password: string;
}

const InputLogin = () => {
  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<RMS_LoginProps>({
    defaultValues: {
      userID: '',
      password: '',
    },
  });

  const { dispatch } = useContext(AuthUploadRecipeContext);

  const { delayFocus: passwordFocus, component: PasswordComponent } =
    useRefInput(Input);

  const handleLogin = async (data: RMS_LoginProps) => {
    try {
      const res = await authenticateUser(data);
      dispatch({ type: 'SIGN_SUCC', payload: { ...data, checkLogin: true } });
      ToastAndroid.show(ToastMessage(res), ToastAndroid.LONG);
    } catch (error) {
      ToastAndroid.show(ToastMessage(error as responseType), ToastAndroid.LONG);
    }
  };
  return (
    <CommonBox>
      <FormControl isRequired isInvalid={!!errors.userID?.message}>
        <FormControl.Label>用户名</FormControl.Label>
        <Controller
          rules={{
            required: '用户名必填',
          }}
          control={control}
          render={({ field: { onChange, value } }) => (
            <Input
              value={value}
              onChangeText={onChange}
              onSubmitEditing={() => {
                passwordFocus();
              }}
            />
          )}
          name="userID"
        />
        <FormControl.ErrorMessage>
          {errors.userID?.message}
        </FormControl.ErrorMessage>
      </FormControl>
      <FormControl isRequired isInvalid={!!errors.password?.message}>
        <FormControl.Label>密码</FormControl.Label>
        <Controller
          rules={{
            required: '密码必填',
          }}
          control={control}
          render={({ field: { onChange, value } }) => (
            <PasswordComponent
              type="password"
              value={value}
              onChangeText={onChange}
            />
          )}
          name="password"
        />
        <FormControl.ErrorMessage>
          {errors.password?.message}
        </FormControl.ErrorMessage>
      </FormControl>
      <CommonButton
        onPress={handleSubmit(handleLogin)}
        style={{ marginTop: 10 }}>
        登录
      </CommonButton>
    </CommonBox>
  );
};

export default InputLogin;

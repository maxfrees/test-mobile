import React from 'react';
import AuthUploadRecipeProvider from './RecipeProvider';
const AuthUploadRecipe: React.FC = () => {
  return <AuthUploadRecipeProvider />;
};

export default AuthUploadRecipe;

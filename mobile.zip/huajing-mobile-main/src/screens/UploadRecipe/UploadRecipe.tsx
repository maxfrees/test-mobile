import React, { useState, useEffect, useContext } from 'react';
import { Select, Input, FormControl } from 'native-base';
import { useForm, Controller } from 'react-hook-form';
import { getRecipes, uploadRecipes } from '@/services/uploadRecipe';
import { responseType, ToastMessage } from '@/utils/errorMessageMap';
import { useNavigation } from '@react-navigation/native';
import { getEqpId } from '@/utils/user';
import { AuthUploadRecipeContext } from './RecipeProvider';
import useToast from '@/hooks/useToast';
import CommonBox from '@/components/common/CommonBox';
import CommonGridView from '@/components/common/CommonGrid';
import CommonButton from '@/components/common/CommonButton';

export interface UploadRecipeProps {
  eqpId: string;
  recipeName: string;
  userID: string;
}

const UploadRecipe: React.FC = () => {
  const { userID } = useContext(AuthUploadRecipeContext);

  const navigation = useNavigation();

  const [recipeData, setRecipeData] = useState<Array<string>>([]);

  const { handleSubmit, control, setValue } = useForm<UploadRecipeProps>({
    defaultValues: {
      eqpId: '',
      recipeName: '',
    },
  });

  const { setShowToast } = useToast();

  const onOk = async (data: UploadRecipeProps) => {
    try {
      const res = await uploadRecipes({ ...data, userID });
      setShowToast({
        type: 'success',
        message: ToastMessage(res),
      });
    } catch (error) {
      setShowToast({
        type: 'error',
        message: ToastMessage(error as responseType),
      });
    }
  };

  useEffect(() => {
    (async () => {
      try {
        const eqpId = await getEqpId();
        setValue('eqpId', eqpId);
        const res = await getRecipes({ eqpId: eqpId });
        setRecipeData(res.data);
      } catch (error) {
        setShowToast({
          type: 'error',
          message: ToastMessage(error as responseType),
        });
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [setValue]);

  return (
    <CommonBox>
      <FormControl>
        <FormControl.Label>机台编号</FormControl.Label>
        <Controller
          control={control}
          render={({ field: { value } }) => <Input value={value} isDisabled />}
          name="eqpId"
        />
      </FormControl>
      <FormControl>
        <FormControl.Label>Recipe</FormControl.Label>
        <Controller
          rules={{ required: true }}
          control={control}
          render={({ field: { onChange, value } }) => (
            <Select
              w="100%"
              selectedValue={value}
              onValueChange={(itemValue: string) => {
                onChange(itemValue);
              }}
              _selectedItem={{
                bg: 'info.100',
              }}>
              {recipeData.map(item => (
                <Select.Item label={item} value={item} key={item} />
              ))}
            </Select>
          )}
          name="recipeName"
        />
      </FormControl>
      <CommonGridView numOfRow={2} style={{ marginTop: 20 }}>
        <CommonButton onPress={handleSubmit(onOk)}>确认上传</CommonButton>
        <CommonButton
          onPress={() => {
            navigation.goBack();
          }}>
          返回主页面
        </CommonButton>
      </CommonGridView>
    </CommonBox>
  );
};

export default UploadRecipe;

import React, { useContext, useEffect } from 'react';
import { ScrollView, StyleSheet } from 'react-native';
import { Input, FormControl } from 'native-base';
import { useForm, Controller, SubmitHandler } from 'react-hook-form';
import { doUpdate } from '@/services/handOver';
import { useNavigation, CommonActions } from '@react-navigation/native';
import { responseType, ToastMessage } from '@/utils/errorMessageMap';
import { AuthContext } from '@/context/AuthProvider';
import LoadingButton from '@/components/LoadingButton';
import { getLotInfo } from '@/services/public';
import useToast from '@/hooks/useToast';
import CommonBox from '@/components/common/CommonBox';
import { getStorageEqpId } from '@/storage/eqpId';

interface HandOverForm {
  lotId: string;
  eqpId: string;
  userId: string;
  quotaCode: string;
  deviceQty: string;
  qty: string;
}

const Handover: React.FC = () => {
  const {
    handleSubmit,
    control,
    reset,
    formState: { errors },
  } = useForm<HandOverForm>({
    defaultValues: {
      lotId: '',
      eqpId: '',
      userId: '',
      quotaCode: '',
      deviceQty: '',
      qty: '',
    },
  });

  const eqpId = getStorageEqpId() as string;

  const { setShowToast } = useToast();

  const navigation = useNavigation();

  const { logout, changeHandOver, lotForm, openLoginPopup } =
    useContext(AuthContext);

  const onSubmit: SubmitHandler<HandOverForm> = async data => {
    if (Number(data.qty) > Number(data.deviceQty)) {
      setShowToast({
        type: 'error',
        message: '实物数量不能大于系统数量',
      });
      return;
    }

    if (Number(data.qty) <= 0) {
      setShowToast({
        type: 'error',
        message: '实物数量大于0',
      });
      return;
    }

    try {
      const res = await doUpdate({
        eqpId: data.eqpId,
        lotId: data.lotId,
        qty: data.qty,
      });
      logout();
      changeHandOver(true);
      openLoginPopup(true);
      navigation.dispatch(
        CommonActions.navigate({
          name: 'Home',
        }),
      );
      setShowToast({
        type: 'success',
        message: ToastMessage(res),
      });
    } catch (error) {
      setShowToast({
        type: 'error',
        message: '系统未知异常',
      });
    }
  };

  const gethandeOverForm = async (id: string) => {
    try {
      const res = await getLotInfo({
        eqpId: eqpId,
        lotId: id,
      });
      const {
        quotaCode,
        deviceQty,
        lotId,
        operId,
        eqpId: updateEqpId,
      } = res.data;

      reset({
        lotId: lotId,
        userId: operId,
        eqpId: updateEqpId,
        quotaCode: quotaCode,
        deviceQty: deviceQty,
      });
    } catch (error) {
      setShowToast({
        type: 'error',
        message: ToastMessage(error as responseType),
      });
    }
  };

  const getOverForm = () => {
    if (lotForm.lotId) {
      gethandeOverForm(lotForm.lotId);
    }
  };

  useEffect(() => {
    getOverForm();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <ScrollView style={styles.layout}>
      <CommonBox>
        <FormControl isRequired isInvalid={'lotId' in errors}>
          <FormControl.Label>作业批号: </FormControl.Label>
          <Controller
            control={control}
            rules={{ required: '请输入作业批号' }}
            render={({ field: { onChange, value } }) => (
              <Input
                w={'100%'}
                autoCapitalize="none"
                secureTextEntry={true}
                keyboardType={'visible-password'}
                onSubmitEditing={() => gethandeOverForm(value)}
                blurOnSubmit={true}
                value={value}
                onChangeText={text => {
                  onChange(text.replace(/——/g, '-').toUpperCase());
                }}
                autoFocus
              />
            )}
            name="lotId"
          />
          <FormControl.ErrorMessage>
            {errors.lotId?.message}
          </FormControl.ErrorMessage>
        </FormControl>
        <FormControl>
          <FormControl.Label>机台号: </FormControl.Label>
          <Controller
            control={control}
            render={({ field: { value } }) => (
              <Input w="100%" value={value} isDisabled />
            )}
            name="eqpId"
          />
        </FormControl>
        <FormControl>
          <FormControl.Label>作业员: </FormControl.Label>
          <Controller
            control={control}
            render={({ field: { value } }) => (
              <Input w="100%" value={value} isDisabled />
            )}
            name="userId"
          />
        </FormControl>
        <FormControl>
          <FormControl.Label>定额代码: </FormControl.Label>
          <Controller
            control={control}
            render={({ field: { value } }) => (
              <Input w="100%" value={value} isDisabled />
            )}
            name="quotaCode"
          />
        </FormControl>
        <FormControl>
          <FormControl.Label>系统数量: </FormControl.Label>
          <Controller
            control={control}
            render={({ field: { value } }) => (
              <Input w="100%" value={value} isDisabled />
            )}
            name="deviceQty"
          />
        </FormControl>
        <FormControl isRequired isInvalid={'qty' in errors}>
          <FormControl.Label>实物数量: </FormControl.Label>
          <Controller
            control={control}
            rules={{ required: '请输入实物数量' }}
            render={({ field: { onChange, value } }) => (
              <Input
                w="100%"
                value={value}
                onChangeText={text => {
                  const val = text.replace(/[^0-9]/g, '');
                  onChange(val);
                }}
                keyboardType="number-pad"
              />
            )}
            name="qty"
          />
          <FormControl.ErrorMessage>
            {errors.qty?.message}
          </FormControl.ErrorMessage>
        </FormControl>
        <LoadingButton
          style={{ marginTop: 20 }}
          title="确认交接"
          onPress={handleSubmit(onSubmit)}
        />
      </CommonBox>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  layout: {
    flex: 1,
  },
});
export default Handover;

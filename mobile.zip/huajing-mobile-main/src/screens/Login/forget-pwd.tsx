import React, { useEffect, useReducer, useContext, Reducer } from 'react';
import { FormControl, VStack, Text } from 'native-base';
import { CommonActions, useNavigation } from '@react-navigation/native';
import { getUserInfo } from '@/utils/user';
import AffixInput from '@/components/AffixInput';
import LoadingButton from '@/components/LoadingButton';
import type { updatePwdType } from '@/services/login';
import { updatePasswordByUserId } from '@/services/login';
import { responseType, ToastMessage } from '@/utils/errorMessageMap';
import { AuthContext } from '@/context/AuthProvider';
import useToast from '@/hooks/useToast';
import CommonBox from '@/components/common/CommonBox';

const initialState: updatePwdType = {
  id: '',
  oldpassword: '',
  newpassword: '',
};

type ActionType = {
  type: 'id' | 'oldpassword' | 'newpassword';
  payload: string;
};

const reducer: Reducer<updatePwdType, ActionType> = (state, action) => {
  switch (action.type) {
    case 'id':
      return {
        ...state,
        id: action.payload,
      };
    case 'oldpassword':
      return {
        ...state,
        oldpassword: action.payload,
      };
    case 'newpassword':
      return {
        ...state,
        newpassword: action.payload,
      };
    default:
      return state;
  }
};

const ForgetPwd: React.FC = () => {
  const [state, dispatch] = useReducer(reducer, initialState);

  const { setShowToast } = useToast();

  const { logout } = useContext(AuthContext);
  const navigation = useNavigation();

  useEffect(() => {
    const getName = async () => {
      try {
        const res = await getUserInfo();
        dispatch({
          type: 'id',
          payload: res.userID,
        });
      } catch (error) {}
    };
    getName();
  }, []);

  const handleSettingPwd = async () => {
    try {
      await updatePasswordByUserId(state);
      navigation.dispatch(
        CommonActions.reset({
          index: 0,
          routes: [{ name: 'Home' }],
        }),
      );
      logout();
    } catch (error) {
      setShowToast({
        type: 'error',
        message: ToastMessage(error as responseType),
      });
    }
  };

  return (
    <CommonBox style={{ flex: 1 }}>
      <VStack space={3}>
        <FormControl>
          <FormControl.Label>账户</FormControl.Label>
          <Text>{state.id}</Text>
        </FormControl>
        <FormControl>
          <FormControl.Label>旧密码</FormControl.Label>
          <AffixInput
            type="password"
            onChangeText={(text: string) =>
              dispatch({ type: 'oldpassword', payload: text })
            }
            placeholder="请填写旧密码"
          />
        </FormControl>
        <FormControl>
          <FormControl.Label>新密码</FormControl.Label>
          <AffixInput
            type="password"
            onChangeText={(text: string) =>
              dispatch({ type: 'newpassword', payload: text })
            }
            placeholder="请输入新的密码"
          />
        </FormControl>
        <LoadingButton
          mt="2"
          title="确认修改"
          isDisabled={state.newpassword && state.oldpassword ? false : true}
          onPress={handleSettingPwd}
        />
      </VStack>
    </CommonBox>
  );
};

export default ForgetPwd;

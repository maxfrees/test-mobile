import React from 'react';
import { Modal } from 'native-base';

import TabLogin from '@/modules/Login';
import { resetNavigate } from '@/utils/RootNavigation';
interface loginPopupProps {
  isShow: boolean;
  needLogin: (show: boolean) => void;
}

const Login: React.FC<loginPopupProps> = ({ isShow, needLogin }) => {
  const onClose = () => {
    needLogin(!isShow);
  };

  const loginSuccess = () => {
    needLogin(false);
    resetNavigate();
  };

  return (
    <Modal
      avoidKeyboard
      safeAreaTop
      isOpen={isShow}
      onClose={onClose}
      animationPreset="slide">
      <Modal.Content w={'80%'}>
        <Modal.CloseButton />
        <Modal.Body>
          <TabLogin loginSuccess={loginSuccess} />
        </Modal.Body>
      </Modal.Content>
    </Modal>
  );
};

export default Login;

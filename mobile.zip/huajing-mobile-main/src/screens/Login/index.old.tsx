import { FormControl, Input, Modal, VStack } from 'native-base';
import React, { useContext } from 'react';
import { getUniqueId } from 'react-native-device-info';
import { AuthContext } from '@/context/AuthProvider';
import { accountLogin, updateOperId } from '@/services/login';
import { responseType, ToastMessage } from '@/utils/errorMessageMap';
import { setEqpId, setUserInfo } from '@/utils/user';
import { resetNavigate } from '@/utils/RootNavigation';
import useToast from '@/hooks/useToast';
import { useForm, Controller } from 'react-hook-form';
import useRefInput from '@/hooks/useRefInput';
import { setStorageEqpId } from '@/storage/eqpId';
import CommonButton from '@/components/common/CommonButton';

interface loginPopupProps {
  isShow: boolean;
  needLogin: (show: boolean) => void;
}

interface FormData {
  username: string;
  password: string;
}

const Login: React.FC<loginPopupProps> = ({ isShow, needLogin }) => {
  const { delayFocus: passwordFocus, component: PasswordComponent } =
    useRefInput(Input);

  const {
    control,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm<FormData>({
    defaultValues: {
      username: '',
      password: '',
    },
  });

  const { login } = useContext(AuthContext);

  const { setShowToast } = useToast();

  const handleLogin = async (data: FormData) => {
    try {
      // 使用ipaddress字段替代androd id
      const ipaddress = getUniqueId();
      const res = await accountLogin({
        ...data,
        ipaddress: __DEV__ ? '7b1ab614a2d3f83f' : ipaddress,
        loginType: 3,
      });
      const { token, eqpid, user } = res.data;

      setStorageEqpId(eqpid);

      setEqpId(eqpid)
        .then(() => {
          reset();
          setUserInfo({ ...user, eqpId: eqpid });
          login(token);
        })
        .then(() => {
          updateOperId({
            eqpId: res.data.eqpid,
            operId: res.data.user.userID,
          });
        })
        .then(() => {
          setShowToast({
            type: 'success',
            message: ToastMessage(res),
          });
          resetNavigate();
        });
    } catch (error) {
      setShowToast({
        type: 'success',
        message: ToastMessage(error as responseType),
        duration: 4000,
      });
    }
  };

  const onClose = () => {
    reset();
    needLogin(!isShow);
  };

  return (
    <Modal
      avoidKeyboard
      safeAreaTop
      isOpen={isShow}
      onClose={onClose}
      animationPreset="slide">
      <Modal.Content>
        <Modal.CloseButton />
        <Modal.Body>
          <VStack space={2} mt={5}>
            <FormControl isRequired isInvalid={!!errors.username?.message}>
              <FormControl.Label>用户名</FormControl.Label>
              <Controller
                rules={{
                  required: '用户名必填',
                }}
                control={control}
                render={({ field: { onChange, value } }) => (
                  <Input
                    value={value}
                    onChangeText={onChange}
                    onSubmitEditing={() => {
                      passwordFocus();
                    }}
                  />
                )}
                name="username"
              />
              <FormControl.ErrorMessage>
                {errors.username?.message}
              </FormControl.ErrorMessage>
            </FormControl>
            <FormControl isRequired isInvalid={!!errors.password?.message}>
              <FormControl.Label>密码</FormControl.Label>
              <Controller
                rules={{
                  required: '密码必填',
                }}
                control={control}
                render={({ field: { onChange, value } }) => (
                  <PasswordComponent
                    type="password"
                    value={value}
                    onChangeText={onChange}
                  />
                )}
                name="password"
              />
              <FormControl.ErrorMessage>
                {errors.password?.message}
              </FormControl.ErrorMessage>
            </FormControl>
            <VStack space={2}>
              <CommonButton onPress={handleSubmit(handleLogin)}>
                登录
              </CommonButton>
            </VStack>
          </VStack>
        </Modal.Body>
      </Modal.Content>
    </Modal>
  );
};

export default Login;

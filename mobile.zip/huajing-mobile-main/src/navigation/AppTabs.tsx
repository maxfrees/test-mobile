import React from 'react';
import { View } from 'native-base';
import { StyleSheet } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { IconOutline } from '@ant-design/icons-react-native';
import { AppTabParamList } from '@/types/AppTabParamList';

const AppTabs = () => {
  const Tab = createBottomTabNavigator<AppTabParamList>();
  return (
    <Tab.Navigator initialRouteName="AppHome">
      <Tab.Screen
        name="AppHome"
        getComponent={() => require('@/screens/Home').default}
        options={{
          tabBarLabel: '首页',
          tabBarIcon: ({ color, size }) => {
            return <IconOutline name="home" size={size} color={color} />;
          },
        }}
      />
      <Tab.Screen
        name="Message"
        getComponent={() => require('@/screens/Message').default}
        options={{
          tabBarLabel: '消息列表',
          tabBarIcon: ({ color, size }) => {
            return (
              <View style={styles.messageTips}>
                <IconOutline name="message" size={size} color={color} />
              </View>
            );
          },
        }}
      />
      <Tab.Screen
        name="My"
        getComponent={() => require('@/screens/My').default}
        options={{
          tabBarLabel: '我的',
          tabBarIcon: ({ color, size }) => {
            return <IconOutline name="user" size={size} color={color} />;
          },
        }}
      />
    </Tab.Navigator>
  );
};

const styles = StyleSheet.create({
  messageTips: {
    position: 'relative',
  },
  messageBadge: {
    position: 'absolute',
    top: -4,
    right: -14,
    backgroundColor: '#f56c6c',
    zIndex: 2,
    alignItems: 'center',
    borderRadius: 10,
    paddingHorizontal: 4,
  },
  badge__content: {
    color: '#fff',
    fontSize: 12,
  },
});
export default AppTabs;

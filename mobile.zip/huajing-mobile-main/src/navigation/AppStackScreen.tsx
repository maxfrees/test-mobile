import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { AppStackParamList } from '@/types/AppStackParamList';
import { routers } from '@/routers';
import { headerStyle } from '@/theme/navigatorStyles';
import AppTabs from './AppTabs';

const RootStack = createStackNavigator<AppStackParamList>();

export const AppStackScreen: React.FC = () => {
  return (
    <RootStack.Navigator initialRouteName="Home">
      <RootStack.Screen
        name="Home"
        component={AppTabs}
        options={{ headerShown: false }}
      />
      {/* 所有路由表 */}
      {routers.map(route => {
        return (
          <RootStack.Screen
            key={route.name}
            name={route.name}
            getComponent={route.component}
            options={{
              headerTitle: route.title,
              headerTitleAlign: 'center',
              ...headerStyle,
            }}
            initialParams={route.initialParams}
          />
        );
      })}
    </RootStack.Navigator>
  );
};

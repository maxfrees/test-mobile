import React, { useCallback, useRef, useState } from 'react';
import { IInputProps } from 'native-base';
import { IInputComponentType } from 'native-base/lib/typescript/components/primitives/Input/types';

interface InputElTypes {
  focus: () => void;
}
export default function useRefInput(Component: IInputComponentType): {
  focus: () => void;
  setDisabled: (bool: boolean) => void;
  delayFocus: () => void;
  component: IInputComponentType;
} {
  const wrappedEl = useRef<InputElTypes | null>(null);

  const [disabled, setDisabled] = useState<boolean>(false);

  const WrappedComponent = useCallback(
    (props: IInputProps) => {
      return <Component ref={wrappedEl} isDisabled={disabled} {...props} />;
    },
    [disabled],
  );

  const handleFocus = () => {
    wrappedEl.current && wrappedEl.current.focus();
  };

  const handleDelayFocus = (delay: number = 400) => {
    setTimeout(() => {
      wrappedEl.current && wrappedEl.current.focus();
    }, delay);
  };

  const setInputDisabled = (bool: boolean) => {
    setDisabled(bool);
  };

  return {
    focus: handleFocus,
    setDisabled: setInputDisabled,
    delayFocus: handleDelayFocus,
    component: WrappedComponent,
  };
}

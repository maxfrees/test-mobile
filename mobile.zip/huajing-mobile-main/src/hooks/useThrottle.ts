import { useRef, useEffect, useCallback } from 'react';

type Timeout = ReturnType<typeof setTimeout>;

export const useThrottle = (callback: () => void, delay: number) => {
  const savedCallback = useRef<{
    fn: Function;
    timer: null | Timeout;
  }>({ fn: callback, timer: null });
  // 保存新回调
  useEffect(() => {
    savedCallback.current.fn = callback;
  });

  return useCallback(() => {
    if (!savedCallback.current.timer) {
      savedCallback.current.timer = setTimeout(() => {
        savedCallback.current.timer = null;
      }, delay);
      savedCallback.current.fn();
    }
  }, [delay]);
};

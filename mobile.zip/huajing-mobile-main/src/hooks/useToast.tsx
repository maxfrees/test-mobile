import React, { useCallback, useEffect, useRef } from 'react';
import { CloseIcon, IconButton, Text, Toast, View } from 'native-base';
import { useWindowDimensions } from 'react-native';

interface ToastProps {
  type: 'success' | 'error';
  message: string;
  duration?: number;
}

let idx = 0;
export default function useToast() {
  const toastIdRef = useRef();
  const windowWidth = useWindowDimensions().width;

  const setShowToast = useCallback(
    ({ type, message, duration = 2000 }: ToastProps) => {
      const currentId = idx++;
      // const backgroundColor = type === 'success' ? '#22c55e' : '#ef4444';
      toastIdRef.current = Toast.show({
        id: currentId,
        render: () => {
          return (
            <View
              style={{
                width: windowWidth - 40,
                flexDirection: 'row',
                alignSelf: 'center',
                alignItems: 'center',
                justifyContent: 'space-between',
                paddingVertical: 4,
                backgroundColor: '#404040',
                borderRadius: 10,
                paddingHorizontal: 10,
              }}>
              <Text color="#fff" style={{ flex: 1, flexWrap: 'wrap' }}>
                {message}
              </Text>
              <IconButton
                variant="unstyled"
                icon={<CloseIcon size="3" />}
                _icon={{
                  color: 'lightText',
                }}
                onPress={() => {
                  Toast.close(currentId);
                }}
              />
            </View>
          );
        },
        duration: type === 'success' ? duration : null,
      });
    },
    [windowWidth],
  );

  const closeToast = () => {
    Toast.closeAll();
  };

  useEffect(() => {
    return closeToast;
  }, []);

  return {
    setShowToast,
    closeToast,
  };
}

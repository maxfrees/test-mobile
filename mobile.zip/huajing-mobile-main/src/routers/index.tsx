import { AppStackParamList } from '@/types/AppStackParamList';

type IRoutes = {
  name: keyof AppStackParamList;
  title: string;
  component: () => React.ComponentType<any>;
  initialParams?: Partial<AppStackParamList[keyof AppStackParamList]>;
};

export const routers: IRoutes[] = [
  {
    name: 'TrackIn',
    title: '开批',
    component: () => require('@/screens/TrackIn').default,
  },
  {
    name: 'TrackOut',
    title: '结批',
    component: () => require('@/screens/TrackOut').default,
  },
  {
    name: 'MaterialChange',
    title: '物料新增和修改',
    component: () => require('@/screens/MaterialChange').default,
  },
  {
    name: 'MaterialsHistory',
    title: '物料历史记录',
    component: () => require('@/screens/MaterialsHistory').default,
  },
  {
    name: 'Discontinue',
    title: '作业中止',
    component: () => require('@/screens/Discontinue').default,
  },
  {
    name: 'CraftCard',
    title: '工艺卡片',
    component: () => require('@/screens/CraftCard').default,
  },
  {
    name: 'ChangeOEE',
    title: 'OEE切换',
    component: () => require('@/screens/ChangeOEE').default,
  },
  {
    name: 'Handover',
    title: '产量交班',
    component: () => require('@/screens/Handover').default,
  },
  {
    name: 'RMS',
    title: 'RMS',
    component: () => require('@/screens/RMS').default,
  },
  {
    name: 'Setting',
    title: '设置',
    component: () => require('@/screens/Setting').default,
  },
  {
    name: 'PadQRCode',
    title: '设备二维码',
    component: () => require('@/screens/PadQRCode').default,
  },
  {
    name: 'ForgetPwd',
    title: '设置登录密码',
    component: () => require('@/screens/Login/forget-pwd').default,
  },
  {
    name: 'UploadRecipe',
    title: '上传Recipe',
    component: () => require('@/screens/UploadRecipe').default,
  },
];

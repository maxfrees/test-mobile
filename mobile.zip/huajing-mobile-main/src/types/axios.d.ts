// eslint-disable-next-line @typescript-eslint/no-unused-vars
import axios from 'axios';

export type IAxios<D = any> = {
  code: number;
  message: number;
  data: D;
};

declare module 'axios' {
  /**
   * @param {code} string
   * @param {msg} number
   * @param {data} any
   */
  export interface AxiosResponse<T = any> extends Promise<IAxios<T>> {}
}

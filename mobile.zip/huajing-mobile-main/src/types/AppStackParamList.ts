import { RouteProp } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';

export type AppStackParamList = {
  Home: undefined;
  TrackIn: undefined;
  TrackOut: undefined;
  Handover: undefined;
  Setting: undefined;
  CraftCard: undefined;
  ChangeOEE: undefined;
  MaterialChange: undefined;
  Discontinue: undefined;
  MaterialsHistory: { lotId: string };
  RMS: undefined;
  PadQRCode: undefined;
  ForgetPwd: undefined;
  UploadRecipe: undefined;
};

export type AuthNavProps<T extends keyof AppStackParamList> = {
  navigation: StackNavigationProp<AppStackParamList, T>;
  route: RouteProp<AppStackParamList, T>;
};

export type AppTabParamList = {
  AppHome: undefined;
  Message: undefined;
  My: undefined;
};

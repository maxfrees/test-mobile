import axios from 'axios';
import { getToken, removeToken } from './auth';
import { resetNavigate } from './RootNavigation';
import { removeUserInfo } from './user';

export const BASE_API = __DEV__
  ? 'http://10.16.7.41:9107'
  : 'http://192.168.20.8:8100';


const service = axios.create({
  baseURL: BASE_API,
  timeout: 60000,
  withCredentials: true, // 携带cookie
});

// Add a request interceptor
service.interceptors.request.use(
  async config => {
    const authToken = await getToken();
    if (authToken) {
      // config.headers.Token = authToken;
      config.headers = {
        Token: authToken,
      };
    }
    // Do something before request is sent
    // config.headers['Content-Type'] = 'application/json';
    return config;
  },
  function (error) {
    // Do something with request error
    return Promise.reject(error);
  },
);

// Add a response interceptor
service.interceptors.response.use(
  function (response) {
    const result = response.data.message;
    if (result >= 1005 && result <= 1013) {
      removeToken();
      removeUserInfo();
      resetNavigate();
    }

    // code为1才成功
    if (response.data.code === 1) {
      return response.data;
    } else {
      return Promise.reject(response.data);
    }
    // Any status code that lie within the range of 2xx cause this function to trigger
    // Do something with response data
  },
  function (error) {
    // Any status codes that falls outside the range of 2xx cause this function to trigger
    // Do something with response error
    // https://www.axios-http.cn/docs/handling_errors 详见文档
    if (error.response) {
      return Promise.reject(error.response.data);
    } else {
      return Promise.reject(error.toJSON().message);
    }
  },
);
export default service;

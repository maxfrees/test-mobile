export function isDef(v: any): boolean {
  return v !== undefined && v !== null;
}

export function isPromise(val: any): boolean {
  return (
    isDef(val) &&
    typeof val.then === 'function' &&
    typeof val.catch === 'function'
  );
}

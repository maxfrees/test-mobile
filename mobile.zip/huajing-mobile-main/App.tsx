import React from 'react';
import 'react-native-gesture-handler';
import { SafeAreaView, StatusBar, StyleSheet } from 'react-native';
import { LoadingContextProvider } from '@/context/LoadingContext';
import { AuthProvider } from '@/context/AuthProvider';
import { NavigationContainer } from '@react-navigation/native';
import { navigationRef } from '@/utils/RootNavigation';
import { AppStackScreen } from '@/navigation/AppStackScreen';

const App: React.FC = () => {
  return (
    <SafeAreaView style={styles.container}>
      <AuthProvider>
        <NavigationContainer ref={navigationRef}>
          <StatusBar backgroundColor="rgba(0, 0, 0, 0)" translucent />
          <LoadingContextProvider>
            <AppStackScreen />
          </LoadingContextProvider>
        </NavigationContainer>
      </AuthProvider>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});

export default App;
